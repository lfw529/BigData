import sys
import requests
import pymysql
import json
import jsonpath
import datetime
import psycopg2

##调度上线告警
### 监控 ###

def get_data_from_mysql(sql):
    connect = pymysql.connect(
        host='bdmysql-p-01',
        port=3306,
        database='dolphinscheduler',
        user='cdh_user',
        passwd='Cdh#@20211014',
        charset='utf8',
        init_command="SET SESSION time_zone='+08:00'")
    cursor = connect.cursor()
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
    except:
        print("Error: unable to fetch data")
    connect.close()


def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {

        "msgtype": "markdown",
        "markdown": {
            "content": content
        }
    }
    data = json.dumps(data)
    info = requests.post(url=webhook, data=data, headers=header)


def send_text(webhook, content, mentioned_list=None, mentioned_mobile_list=None):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {

        "msgtype": "text",
        "text": {
            "content": content
            , "mentioned_list": mentioned_list
            , "mentioned_mobile_list": mentioned_mobile_list
        }
    }
    data = json.dumps(data)
    info = requests.post(url=webhook, data=data, headers=header)


def get_cont(id, code, name, description, user_name, project_code, release_state):
    cont = '- ' + "**<font color=\"#858585\"  > 生产环境调度上线状态监控</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务ID：</font>** <font color=\"#858585\"  > " + id + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务编码：</font>** <font color=\"#858585\"  > " + code + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务名称 ：</font>** <font color=\"#858585\"  > " + name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务描述：</font>** <font color=\"#858585\"  > " + description + "</font> " + '\n'
    # cont = cont + '- ' + "**<font color=\"#858585\"  > 任务状态：</font><font color=\"#FF0000\" > 任务执行失败</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 执行人：</font>** <font color=\"#858585\" > " + user_name + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 项目编码：</font>** <font color=\"#858585\" > " + project_code + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 定时任务状态：</font><font color=\"#FF0000\" > 定时任务未上线</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  >[**请及时点击处理**](http://10.30.250.23:12345/dolphinscheduler/ui/view/login/index.html)</font>** \n"
    return cont


def get_fault_cont(title, hosts, start_time, typename, event, level, alert_log):
    cont = '- ' + "**<font color=\"#858585\"  > 告警类型：</font>** <font color=\"#858585\"  > " + title + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警服务器：</font>** <font color=\"#858585\"  > " + hosts + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 服务告警时间：</font>** <font color=\"#858585\"  > " + start_time + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 角色：</font>** <font color=\"#FF0000\"  > " + typename + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 事件：</font>** <font color=\"#858585\" > " + event + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警级别：</font><font color=\"#858585\" > " + level + "</font>**  \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > alert告警日志：</font>** <font color=\"#858585\"  > " + alert_log + "</font> " + '\n'
    return cont


def analysis_processing(env, min):
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=min)).strftime("%Y-%m-%d %H:%M:%S")
    process_definition = "select p1.id,p1.code,p1.name,p1.description,p2.user_name,p1.project_code,p3.release_state,p2.phone " \
                         "from t_ds_process_definition p1 " \
                         "left outer join t_ds_user p2 " \
                         "on p1.user_id = p2.id " \
                         "left join t_ds_schedules p3 " \
                         "on p1.code = p3.process_definition_code " \
                         "where p1.id not in (1,2,3,4,5,26,51,44,7,19,22,60,64,67,68,69,72,76,38,102,103,111,116,113,159,213,258,219,245,246,263,247) and (p3.release_state is null or p3.release_state = 0)"
    print(process_definition)

    result_process_definition = get_data_from_mysql(process_definition)

    if len(result_process_definition) > 0:
        for result in result_process_definition:
            id = str(result[0])
            code = str(result[1])
            name = result[2]
            description = result[3]
            user_name = result[4]
            project_code = str(result[5])
            release_state = str(result[6])
            phone = result[7]
            cont1 = get_cont(id, code, name, description, user_name, project_code, release_state)
            print(cont1)
            webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723"
            content = cont1 + '<@' + phone + '>'
            rs = send_md(webhook, content)
            # xiaoding.send_markdown(title='[调度上线状态监控]',
            #    text="## [" + env + "调度上线状态监控]\n" + cont1,
            #    is_at_all=True)
            # rs2 = send_text(webhook, content='小企提醒,及时上线工作流哦', mentioned_mobile_list= phone)


def main():
    try:
        # 每10分钟，执行一次
        # 执行数据获取多冗余1分钟 保证不漏发
        analysis_processing("生产环境", 11)
    except (KeyboardInterrupt, SystemExit):
        sys.exit("程序退出~")


if __name__ == '__main__':
    main()