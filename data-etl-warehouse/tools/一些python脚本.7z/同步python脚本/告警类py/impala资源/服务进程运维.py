import paramiko
import json
from dingtalkchatbot.chatbot import DingtalkChatbot
import traceback

#需要监控的进程配置信息，"进程名":{进程说明,所属服务器,进程个数}
moni_init = '''{
    "supling-web-pro": {"proc_desc" : "灵昭数据查询服务(老pro环境)", "hosts" : ["bdtool", "bdtool-p-04"], "proc_num" : "1"},
	"supling-web-uat": {"proc_desc" : "灵昭数据查询服务(老uat环境)", "hosts" : ["bdtool-"], "proc_num" : "1"},
	"supxi-web-pro": {"proc_desc" : "羲和数据服务管理中心(老pro环境)", "hosts" : ["bdtool"], "proc_num" : "1"},
	"kafdrop": {"proc_desc" : "kafka数据查询平台(pro环境)", "hosts" : ["bdtool"], "proc_num" : "1"},
	"kafka-eagle": {"proc_desc" : "kafka管理平台(pro环境)", "hosts" : ["bdtool"], "proc_num" : "1"},
	"flink-streaming-web": {"proc_desc" : "flink-sql流计算平台(pro环境)", "hosts" : ["bdtool"], "proc_num" : "1"},
	"griffin": {"proc_desc" : "数据质量监控平台(pro环境)", "hosts" : ["bdtool1"], "proc_num" : "1"},
	"redis-server": {"proc_desc" : "redis集群(pro环境)", "hosts" : ["bdda6", "bddatanod", "bddatanod", "bdda", "bddatanode-p-10"], "proc_num" : "2"},
	"apollo-configservice": {"proc_desc" : "apollo配置中心configservice服务(pro环境)", "hosts" : ["bdt", "bdtoo"], "proc_num" : "1"},
	"apollo-adminservice": {"proc_desc" : "apollo配置中心adminservice服务(pro环境)", "hosts" : ["bdtoo", "bd"], "" : "1"},
	"apollo-portal": {"proc_desc" : "apollo配置中心portal服务(pro环境)", "hosts" : ["b"], "proc_num" : "1"}
}
'''
passwd_init = '''{
    "bddatanode-p-01": "h",
    "bddatanode-p-02": "Xmqqtbh",
    "bddatanode-p-03": "X",
    "bddatanode-p-04": "Xh",
    "bddatanode-p-05": "X",
    "bddatanode-p-06": "Su",
    "bddatanode-p-07": "S2",
    "bddatanode-p-08": "S2",
    "bddatanode-p-09": "S",
    "bddatanode-p-10": "S",
    "bdmaster-p-01": "@",
    "bdmaster-p-02": "Xh",
    "bdtool-p-01": "@",
    "bdtool-p-02": "@",
    "bdtool-p-03": "X",
    "bdtool-p-04": "X",
    "bdtool-p-05": "h",
    "bdtool-p-06": "h",
    "bdmysql-p-01": "",
    "bdmysql-p-02": ""
}
'''

### 钉钉监控 ###
webhook = 'https://oapi.dingtalk.com/robot/send?access_token=a968a55b699a2e38e88dc3471a74b465979a289c1f4825ac9d5b9f5b18854bf7'   ##正式
xiaoding = DingtalkChatbot(webhook)

def get_proc_num(proc_name,hostname,passwd):
    # 实例化ssh客户端
    ssh = paramiko.SSHClient()
    # 创建默认的白名单
    policy = paramiko.AutoAddPolicy()
    # 设置白名单
    ssh.set_missing_host_key_policy(policy)
    # 获取免密登录key
    # pkey = '/root/.ssh/id_rsa'
    # key = paramiko.RSAKey.from_private_key_file(pkey)
    # ssh.load_system_host_keys()
    # 链接服务器
    ssh.connect(
        hostname=hostname  # 服务器的ip
        ,port=22  # 服务器的端口
        ,username = "root" #服务器的用户名
        # ,pkey=key
        ,password = passwd #用户名对应的密码
    )
    # 远程执行命令
    stdin, stdout, stderr = ssh.exec_command("ps -eaf | grep " + proc_name + " | grep -v grep|wc")
    # exec_command 返回的对象都是类文件对象
    # stdin 标准输入 用于向远程服务器提交参数，通常用write方法提交
    # stdout 标准输出 服务器执行命令成功，返回的结果  通常用read方法查看
    # stderr 标准错误 服务器执行命令错误返回的错误值  通常也用read方法
    result = stdout.read().decode()
    proc_num = result.split("      ")[1]
    return proc_num

def proc_moni(moni_init,env):
    init_dict = json.loads(moni_init)
    #print(type(init_list["supling-web-pro"]))
    passwd_init_json = json.loads(passwd_init)
    for proc_name in init_dict:
        print(proc_name)
        proc_desc = init_dict[proc_name]["proc_desc"]
        hosts = init_dict[proc_name]["hosts"]
        proc_num = init_dict[proc_name]["proc_num"]
        for host in hosts:
            print (host)
            passwd = passwd_init_json[host]
            try:
                proc_alive_num = get_proc_num(proc_name, host, passwd)
                if proc_alive_num != proc_num :
                    if proc_alive_num == '0' :
                        msg = "服务进程不存在"
                    else :
                        msg = "服务进程异常"
                    cont1 = get_proc_msg_cont(proc_name, proc_desc, host, proc_alive_num, msg)
                    xiaoding.send_markdown(title='[服务进程监控]',
                                           text="## [" + env + "服务进程监控]\n" + cont1,
                                           is_at_all=True)
            except Exception:
                msg_detail = traceback.format_exc()
                msg = "进程状态获取异常"
                print("Error: "+ host +" 服务器的 "+ proc_name + msg + ":" + msg_detail)
                cont1 = get_exc_msg_cont(proc_name, proc_desc, host, msg, msg_detail)
                xiaoding.send_markdown(title='[服务进程监控]',
                                       text="## [" + env + "服务进程监控]\n" + cont1,
                                       is_at_all=True)

def get_proc_msg_cont(proc_name, proc_desc, host, proc_alive_num, msg):
    cont = '- ' + "**<font color=\"#858585\" size = \"2px\" > 进程名称：</font>** <font color=\"#858585\" size = \"3px\" > " + proc_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 进程说明：</font>** <font color=\"#858585\" size = \"2px\" > " + proc_desc + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 所属服务器：</font>** <font color=\"#858585\" size = \"2px\" > " + host + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 异常说明：</font><font color=\"#FF0000\" size = \"4px\" > " + msg + "</font>**  " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 存活进程数：</font>** <font color=\"#858585\" size = \"2px\"> " + proc_alive_num + "</font> \n"
    return cont

def get_exc_msg_cont(proc_name, proc_desc, host, msg, msg_detail):
    cont = '- ' + "**<font color=\"#858585\" size = \"2px\" > 进程名称：</font>** <font color=\"#858585\" size = \"3px\" > " + proc_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 进程说明：</font>** <font color=\"#858585\" size = \"2px\" > " + proc_desc + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 所属服务器：</font>** <font color=\"#858585\" size = \"2px\" > " + host + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 异常说明：</font><font color=\"#FF0000\" size = \"4px\" > " + msg + "</font>**  " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\" size = \"2px\" > 异常明细：</font><font color=\"#858585\" size = \"2px\" > " + msg_detail + "</font>**  " + '\n'
    return cont

def main():
    proc_moni(moni_init, "生产环境")

if __name__ == '__main__':
    main()