import json

import requests
# 企业微信监控impala资源,内存使用峰值异常，大于30G发送告警
#webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式

def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content+'\n'
            '处理人：<@0120212236>',
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)

def getmess():
    headers = {
        'User-Agent': 'Apipost client Runtime/+https://www.apipost.cn/',
        'Content-Type': 'application/json',
        'Authorization': 'Basic Y3VpanVubGU6Y2psITIwMjMwMjAy',
    }

    params = (
        ('filter', 'memory_aggregate_peak>=42949672960'),
        ('limit', '200'),
        ('offset', '0'),
        ('api_key', 'im'),
    )

    response = requests.get('http://10.30.250.21:7180/api/v33/clusters/bigdata_online/services/impala/impalaQueries', headers=headers, params=params)
    getlist = response.json()["queries"]
    cn = 0
    for i in getlist:
        cn+=1
    return  cn

def get_fault_cont(cn):
    cont = '- ' + "**<font color=\"#858585\"  > 告警类型：IMPALA计算资源告警</font>** <font color=\"#858585\"  > </font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 监控类型：</font>** <font color=\"#FF0000\" > 内存使用峰值异常</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 请及时查看具体任务：</font>** <font color=\"#858585\"  > </font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > [**请及时点击处理**](http://10.30.250.21:7180/cmf/services/18/queries) </font><font color=\"#858585\"  > </font> "
    return cont

if __name__ == '__main__':
    cn = getmess()
    print(cn)
    if cn >0:
        cont = get_fault_cont(cn)
        send_md(webhook, cont)