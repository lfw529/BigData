import requests
import datetime
import cx_Oracle as cx

headers = {'Content-Type': 'application/json;charset=utf-8'}

#企业微信机器人链接
webhook = ""   ##正式

#webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=3b5846d5-5aee-4ec8-853d-23b9857d1cf6"   ##正式

def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)
 #import cx_Oracle as cx

def get_data_from_oracle(sql):
    ip = '10.30.3.2'
    port = '1521'
    sid = 'oadata'
    user = 'kibug'
    pwd = 'supcon1304'
    dsn_tns = cx.makedsn(ip, port, sid)
    connect = cx.connect(user, pwd ,dsn_tns)
    cursor = connect.cursor()
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
    except:
        print("Error: unable to fetch data")
    connect.close()

def post_interface_data(url,headers,bodys):
    requests.post(url=url,data=bodys,headers=headers)


def get_empty_cont(instance_name):
    cont1 = instance_name+" 周报，全员已提交。"+ '\n'
    return cont1

def get_fault_cont(instance_name,task_name):
    cont = instance_name +" 周报提交情况" +'，' + "未提交人:"+' '+task_name +'。'+ '\n'
    return cont

if __name__ == '__main__':
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=11)).strftime("%Y-%m-%d %H:%M:%S")
    #print(monitoring_time)
    sql = """with tt as  (
SELECT
        TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1,'yyyy-mm-dd') AS 日期
        ,TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IYYY') 年份
        ,to_number(TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'MM')) 月份
        ,to_number(TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IW')) 周次
        ,TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IYYY')||'年 第'||to_number(TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IW'))||'周'||'('||TO_CHAR(TRUNC(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1,'iw'),'mm.dd')||'-'||TO_CHAR(TRUNC(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1,'iw')+ 6,'mm.dd')||')' 所属自然周
FROM
        dual
CONNECT BY
        rownum <=(TO_DATE(TO_CHAR(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')-TO_DATE('2022-01-01','yyyy-mm-dd'))+1
ORDER BY
        日期
)
,tt_a as (
select 
distinct
周次
,所属自然周
,substr(所属自然周,6,19) zc
from tt
where 年份=to_char(sysdate,'yyyy')
and 日期<to_char(sysdate,'yyyy-mm-dd') 
and 周次 =(select max(周次) from tt
where 年份=to_char(sysdate,'yyyy')
and 日期<to_char(sysdate,'yyyy-mm-dd') )
order by 周次
)
,tt_m AS (
SELECT 
max(日期) max_date
,min(日期) min_date
FROM tt,tt_a
WHERE tt.所属自然周 =tt_a.所属自然周
)
,b as (SELECT b.id,
oaman.ZK_STR_FORMAT(b.LASTNAME) LASTNAME,
b.DEPARTMENTID,
oaman.ZK_STR_FORMAT(c.DEPARTMENTNAME) 部门,
b.managerid 直接上级id,
oaman.show_username(b.managerid) 直接上级,
e.DEPARTMENTID as 上级部门id,
oaman.ZK_STR_FORMAT(f.DEPARTMENTNAME) 上级部门
FROM oaman.hrmresource b
LEFT JOIN oaman.hrmdepartment c ON b.DEPARTMENTID=c.id
left join  oaman.hrmresource e on  e.id = b.managerid
left join oaman.hrmdepartment f on  f.id = e.DEPARTMENTID
WHERE  b.status NOT IN (4,5,6,7) )
,c as (
select distinct id,LASTNAME,case when  部门 like '%外包%' then 上级部门id else DEPARTMENTID end 部门id,
case when  部门 like '%外包%' then 上级部门 else 部门 end 部门名称,上级部门id
from b
)
,renyuan as (
select 
 id
 ,LASTNAME
 ,部门id
 ,部门名称
 ,上级部门id
 from c where 部门id in ( 27450,54451, 54452) and id not in (6488,1809) AND LASTNAME <> '苏成'  AND LASTNAME <> '王元'  AND LASTNAME <> '魏锋伟'  AND LASTNAME <> '洪文亮'  AND LASTNAME <> '陈绎剀'
 order by 部门名称 ,id
)
select distinct tt_a.zc,a.lastname from renyuan a left join 
(
select OAMAN.ZK_STR_FORMAT(d.lastname) lastname --人员名称
  from  OAMAN.formtable_main_288 a 
  left join OAMAN.formtable_main_288_dt1 b on a.id=b.mainid
  LEFT JOIN OAMAN.workflow_selectitem c on  c.SELECTVALUE=b.lb and fieldid='208836'
  LEFT JOIN OAMAN.hrmresource d ON a.creater=d.id
  WHERE b.lb IS NOT NULL AND b.GSXS IS NOT NULL 
  -- 筛选周
  AND a.kssj BETWEEN (SELECT min_date FROM tt_m) AND (SELECT max_date FROM tt_m)
  and a.CREATER in(select distinct id from renyuan)
  GROUP BY OAMAN.ZK_STR_FORMAT(d.lastname) 
)b 
  on a.lastname = b.lastname
    left join tt_a on 1=1 
    where b.lastname is null """
    sql1="""with tt as  (
SELECT
        TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1,'yyyy-mm-dd') AS 日期
        ,TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IYYY') 年份
        ,to_number(TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'MM')) 月份
        ,to_number(TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IW')) 周次
        ,TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IYYY')||'年 第'||to_number(TO_CHAR(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1, 'IW'))||'周'||'('||TO_CHAR(TRUNC(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1,'iw'),'mm.dd')||'-'||TO_CHAR(TRUNC(TO_DATE('2022-01-01','yyyy-mm-dd')+ rownum-1,'iw')+ 6,'mm.dd')||')' 所属自然周
FROM
        dual
CONNECT BY
        rownum <=(TO_DATE(TO_CHAR(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')-TO_DATE('2022-01-01','yyyy-mm-dd'))+1
ORDER BY
        日期
)
,tt_a as (
select 
distinct
周次
,所属自然周
,substr(所属自然周,6,19) zc
from tt
where 年份=to_char(sysdate,'yyyy')
and 日期<to_char(sysdate,'yyyy-mm-dd') 
and 周次 =(select max(周次) from tt
where 年份=to_char(sysdate,'yyyy')
and 日期<to_char(sysdate,'yyyy-mm-dd') )
order by 周次
)
select zc from tt_a"""

    #获取pg数据库连接 and c.end_time >='%s' % monitoring_time
    rs = get_data_from_oracle(sql)




    if len(rs) == 0:  # Check if task_name is empty
        field_2_values = []
        rs1 = get_data_from_oracle(sql1)
        for i in rs1:
            instance_name = i[0]
        msg1 = get_empty_cont(str(instance_name))
        rs1 = send_md(webhook, msg1)
    else:
        field_2_values = []
        for i in rs:
            instance_name = i[0]
            task_name = i[1]
            field_2_values.append(task_name)
            text = ', '.join(field_2_values)
        msg = get_fault_cont(str(instance_name), text)
        rs = send_md(webhook, msg)
        print(text)
        print(text)