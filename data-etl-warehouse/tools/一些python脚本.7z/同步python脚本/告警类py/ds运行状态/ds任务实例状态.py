import smtplib
from email.mime.text import MIMEText
from email.header import Header
from imp import reload

import psycopg2
import pandas  as pd
import pymysql
import sys
# 引入 datetime 模块
import datetime

# 发信方的信息：发信邮箱，QQ 邮箱授权码
from_addr = 'supdata@supcon.com'
password = 'VPc7MB7e3DIGNYBB'
# 收信方邮箱
to_addr1 = 'lixufang@supcon.com'
to_addr2 = '527615635@qq.com'
to_addrs = ['lixufang@supcon.com','cuijunle@supcon.com','liumingqiu@supcon.com','niebaitian@supcon.com','muliru@supcon.com','zhouzhiyin@supcon.com','qinshunda@supcon.com','heanni@supcon.com']

# 发信服务器
smtp_server = 'mail.supcon.com'
msg=''


def getYesterday():
    today=datetime.date.today()
    oneday=datetime.timedelta(days=1)
    yesterday=today-oneday
    return yesterday


def get_data_from_mysql(sql):
    connect = pymysql.connect(
        host='bdmysql-p-01',
        port=3306,
        database='dolphinscheduler',
        user='cdh_user',
        passwd='Cdh#@20211014',
        charset='utf8',
        init_command="SET SESSION time_zone='+08:00'")
    cursor = connect.cursor()
    try:
        cursor.execute(sql)
        results = cursor.fetchall()

        columnDes = cursor.description #获取连接对象的描述信息
        columnNames = ['运行异常类型','工作流名称','任务实例名称','任务开始时间','任务结束时间','任务执行人']
        #columnNames = [columnDes[i][0] for i in range(len(columnDes))]
        df = pd.DataFrame([list(i) for i in results],columns=columnNames)

        return df
    except:
        print("Error: unable to fetch data")

    cursor.close()
    connect.close()


if __name__ == '__main__':
    #获取ds调度元数据数据库连接
    reload(sys)

    process_definition = "select ta.state ,tb.workflow_name,tc.work_name,start_time,end_time,td.user_name " \
                         "from ( select task_code,process_instance_id,case when state=0 then '提交成功' when state=1 then '正在运行' when state=2 then '准备暂停' when state=3 then '暂停' when state=4 then '准备停止' " \
                         "when state=5 then '停止' when state=6 then '失败' when state=7 then '成功' when state=8 then '需要容错' when state=9 then 'Kill' when state=10 then '等待线程' " \
                         "when state=11 then '等待依赖完成' when state=12 then '延时执行' else '其他状态' end state,start_time,end_time,executor_id " \
                         "from dolphinscheduler.t_ds_task_instance " \
                         "where start_time>= curdate() and state!=7 and task_code not in ( " \
                         "select task_code from dolphinscheduler.t_ds_task_instance where start_time>= curdate() and state=7 ) ) ta " \
                         "left join ( " \
                         "   select t1.id,t2.name workflow_name from dolphinscheduler.t_ds_process_instance t1 " \
                         "left join(select code,name from dolphinscheduler.t_ds_process_definition where project_code=1 ) t2 " \
                         "on t1.process_definition_code = t2.code and t1.start_time >= curdate() " \
                         "where t2.code is not null ) tb " \
                         "on ta.process_instance_id = tb.id " \
                         "left join (   select code,name work_name  from dolphinscheduler.t_ds_task_definition where project_code=1 ) tc " \
                         "on ta.task_code=tc.code " \
                         "left join dolphinscheduler.t_ds_user td " \
                         "on ta.executor_id=td.id " \
                         "where tc.code is not null "

    pd.set_option('display.max_colwidth', None) #设置表格数据完全显示（不出现省略号）
    pd.set_option('display.width', 100)
    df_data = get_data_from_mysql(process_definition)
    df_html = df_data.to_html(escape=False) #DataFrame数据转化为HTML表格形式

    head = """
        <head>
            <meta charset="utf-8">
            <STYLE TYPE="text/css" MEDIA=screen>

                table.dataframe {
                    border-collapse: collapse;
                    border: 2px solid #a19da2;
                    /*居中显示整个表格*/
                    margin: auto;
                }

                table.dataframe thead {
                    border: 2px solid #91c6e1;
                    background: #f1f1f1;
                    padding: 10px 10px 10px 10px;
                    color: #333333;
                }

                table.dataframe tbody {
                    border: 2px solid #91c6e1;
                    padding: 10px 10px 10px 10px;
                }

                table.dataframe tr {

                }

                table.dataframe th {
                    vertical-align: top;
                    font-size: 14px;
                    padding: 10px 10px 10px 10px;
                    color: #105de3;
                    font-family: arial;
                    text-align: center;
                }

                table.dataframe td {
                    text-align: center;
                    padding: 10px 10px 10px 10px;
                }

                body {
                    font-family: 宋体;
                }

                h1 {
                    color: #5db446
                }

                div.header h2 {
                    color: #0002e3;
                    font-family: 黑体;
                }

                div.content h2 {
                    text-align: center;
                    font-size: 28px;
                    text-shadow: 2px 2px 1px #de4040;
                    color: #fff;
                    font-weight: bold;
                    background-color: #008eb7;
                    line-height: 1.5;
                    margin: 20px 0;
                    box-shadow: 10px 10px 5px #888888;
                    border-radius: 5px;
                }

                h3 {
                    font-size: 22px;
                    background-color: rgba(0, 2, 227, 0.71);
                    text-shadow: 2px 2px 1px #de4040;
                    color: rgba(239, 241, 234, 0.99);
                    line-height: 1.5;
                }

                h4 {
                    color: #e10092;
                    font-family: 楷体;
                    font-size: 20px;
                    text-align: center;
                }

                td img {
                    /*width: 60px;*/
                    max-width: 300px;
                    max-height: 300px;
                }

            </STYLE>
        </head>
        """

    body = """
        <body>
        <div align="center" class="header">
            <!--标题部分的信息-->
            <h1 align="center">《数据仓库》项目今日任务调度异常状态告警</h1>
            <h2 align="center">{yesterday}</h2>
        </div>

        <hr>

        <div class="content">
            <!--正文内容-->
            <h2> </h2>

            <div>
                <h4></h4>
                {df_html}

            </div>
            <hr>

            <p style="text-align: center">

            </p>
        </div>
        </body>
        """.format(yesterday=getYesterday(),df_html=df_html)

    if len(df_data) > 0:
        html_msg = "<html>" + head + body + "</html>"
        html_msg = html_msg.replace('\n','').encode("utf-8")

        # 邮箱正文内容，第一个参数为内容，第二个参数为格式(plain 为纯文本)，第三个参数为编码

        msg = MIMEText(html_msg , 'html', 'utf-8')
        # 邮件头信息
        msg['From'] = Header('数据仓库项目任务调度异常状态告警')  # 发送者
        subject = '《数据仓库》项目任务调度异常告警'
        msg['Subject'] = Header(subject, 'utf-8')  # 邮件主题

        smtpobj = smtplib.SMTP_SSL(smtp_server)
        # 建立连接--qq邮箱服务和端口号（可百度查询）
        smtpobj.connect(smtp_server, 465)
        # 登录--发送者账号和口令
        smtpobj.login(from_addr, password)
        # 发送邮件
        smtpobj.sendmail(from_addr, to_addr1, msg.as_string())
        print("邮件发送成功")
        smtpobj.quit()

    else:
        exit(0)
