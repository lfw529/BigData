import sys
import requests
import pymysql
import json
import jsonpath
import datetime
import psycopg2

webhook =
### 钉钉监控 ###
#webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式

def get_data_from_mysql(sql):
    connect = pymysql.connect(
        host='bdmysql-p-01',
        port=3306,
        database='dolphinscheduler',
        user='cdh_user',
        passwd='Cdh#@20211014',
        charset='utf8',
        init_command="SET SESSION time_zone='+08:00'")
    cursor = connect.cursor()
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
    except:
        print("Error: unable to fetch data")
    #connect.close()


def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)


# 远程Greenplum数据库连接参数
def query_from_gp(sql,values):
    # 建立数据库连接
    conn = psycopg2.connect(
        host='10.30.250.135',
        port= 5432,
        database='ads',
        user='dev_user',
        password='DevUser@#20211111'
    )
    cursor = conn.cursor()
    try:
        cursor.execute(sql,values)
        rows = cursor.fetchall()
        return rows
    except psycopg2.Error as e:
        print('连接到远程Greenplum数据库时发生错误:')
        print(e)
# 关闭连接
        cursor.close()
        conn.close()

def get_cont(task_name,task_type,id,process_name,start_time,end_time,yarn_app_id,user_name):
    cont = '- ' + "**<font color=\"#858585\"  > [调度任务监控]</font>**" + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务名称：</font>** <font color=\"#858585\"  > " + task_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 所属工作流：</font>** <font color=\"#858585\"  > " + process_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务类型：</font>** <font color=\"#858585\"  > " + task_type + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务ID：</font>** <font color=\"#858585\"  > " + id + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务状态：</font><font color=\"#FF0000\" > 任务执行失败</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务开始时间：</font>** <font color=\"#858585\" > " + start_time + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务失败时间：</font>** <font color=\"#858585\" > " + end_time + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 执行人：</font>** <font color=\"#858585\"  > " + user_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 关联yarn app id：" + yarn_app_id + "</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  >[**请及时点击处理**](http://10.30.250.23:12345/dolphinscheduler/ui/view/login/index.html)</font>** \n"
    return cont

def get_fault_cont(title,hosts,start_time,typename,event,level,alert_log):
    cont = '- ' + "**<font color=\"#858585\"  > 告警类型：</font>** <font color=\"#858585\"  > " + title + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警服务器：</font>** <font color=\"#858585\"  > " + hosts + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 服务告警时间：</font>** <font color=\"#858585\"  > " + start_time + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务名称：</font>** <font color=\"#858585\"  > " + typename + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 事件：</font>** <font color=\"#858585\"  > " + event + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警级别：</font>** <font color=\"#858585\"  > " + level + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > alert告警日志：</font>** <font color=\"#858585\"  > " + alert_log + "</font> " + '\n'
    return cont

def analysis_processing(env,min):
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=min)).strftime("%Y-%m-%d %H:%M:%S")
    process_instance = "select p1.name,p1.task_type,p1.start_time,p1.id,p1.app_link,p1.end_time,p2.name as process_name,p3.user_name,p3.phone  " \
                       "from t_ds_task_instance p1 " \
                       "inner join t_ds_process_instance p2 " \
                       "on p1.process_instance_id=p2.id " \
                       "inner join t_ds_task_definition  p4 " \
                       "on p1.task_code=p4.code  and p4.project_code <>'10015689101056' " \
                       "left outer join t_ds_user p3  " \
                       "on p4.user_id=p3.id  " \
                       "where p1.state=6 and p1.end_time>='%s'" \
                       "group by p1.name,p2.name having count(1)>1" % monitoring_time
    print(process_instance)

    alert_instance = "select create_time,title,log,content " \
                     "from t_ds_alert " \
                     "where title not like '%%success%%' and create_time>='%s'" % monitoring_time
    print(alert_instance)

    result_process_instance = get_data_from_mysql(process_instance)
    result_alert = get_data_from_mysql(alert_instance)
    conn = psycopg2.connect(
        host='10.30.250.135',
        port=5432,
        database='ads',
        user='dev_user',
        password='DevUser@#20211111'
    )
    cursor = conn.cursor()
    if len(result_process_instance) > 0:
        for result in result_process_instance:
            task_name = result[0]
            task_type = result[1]
            start_time = result[2].strftime('%Y-%m-%d  %H:%M:%S')
            if result[4] is None:
                yarn_app_id = ""
            else:
                yarn_app_id = result[4]
            end_time = result[5].strftime('%Y-%m-%d  %H:%M:%S')
            process_name = result[6]
            user_name = result[7]
            phone = result[8]
            # json_str = json.loads(result[3].replace('\\\\', ''))
            # id = jsonpath.jsonpath(json_str, "$..id")
            id = str(result[3])
            cont1 = get_cont(task_name, task_type, id, process_name, start_time, end_time, yarn_app_id,user_name)
            print(cont1)
            content = cont1 + '<@' + phone + '>'
            rs = send_md(webhook, content)
            insert_sql = "INSERT INTO dev.tpm_ds_task_execution_status_f(task_name,task_type,id,process_name,start_time,end_time,yarn_app_id,user_name) VALUES (%s, %s, %s,%s, %s, %s,%s, %s)"
            print(insert_sql)
            values = (str(task_name), str(task_type), str(id), str(process_name), str(start_time), str(end_time), str(yarn_app_id), str(user_name))

            # 执行插入操作
            cursor.execute(insert_sql, values)

            # 提交事务并关闭连接
        conn.commit()
        cursor.close()
        conn.close()

    if len(result_alert) > 0:
        for result in result_alert:
            start_time = result[0].strftime('%Y-%m-%d  %H:%M:%S')
            title = result[1]
            alert_log = result[2]
            if title == "Fault tolerance warning":
                alert_info = eval(result[3])
                typename = jsonpath.jsonpath(alert_info, "$..type")
                hosts = jsonpath.jsonpath(alert_info, "$..host")
                event = jsonpath.jsonpath(alert_info, "$..event")
                level = jsonpath.jsonpath(alert_info, "$..warning level")
                # text = "服务告警时间:[" + start_time + "] 告警类型:[" + "".join(title) + "] 告警服务器:[" + "".join(hosts) + \
                #        "] 角色:[" + "".join(typename) + "] 事件:[" + "".join(event) + "] 告警级别:[" + "".join(level) + \
                #        "] alert告警日志:[" + alert_log + "]"
                # print(text)
                cont2 = get_fault_cont(title, str(hosts), start_time, typename, event, level, alert_log)
                content = cont2
                rs2 = send_md(webhook, content)

            if  title == "Task Timeout Warn":
                alert_info = eval(result[3])
                typename = jsonpath.jsonpath(alert_info, "$..taskName")
                hosts = jsonpath.jsonpath(alert_info, "$..taskHost")
                event = jsonpath.jsonpath(alert_info, "$..event")
                level = jsonpath.jsonpath(alert_info, "$..warnLevel")
                cont2 = get_fault_cont(str(title), str(hosts), str(start_time), str(typename), str(event), str(level), str(alert_log))
                content = cont2
                rs3 = send_md(webhook, content)



def main():
    try:
        # 每20分钟，执行一次
        # 执行数据获取多冗余1分钟 保证不漏发
        analysis_processing("生产环境",21)
    except (KeyboardInterrupt, SystemExit):
        sys.exit("程序退出~")


if __name__ == '__main__':
    main()
