import sys
import requests
import pymysql
import json
import jsonpath
import datetime

### 企业微信监控 ###
##webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式


def get_data_from_mysql(sql):
    connect = pymysql.connect(
        host='bdmysql-p-01',
        port=3306,
        database='dolphinscheduler',
        user='cdh_user',
        passwd='Cdh#@20211014',
        charset='utf8',
        init_command="SET SESSION time_zone='+08:00'")
    cursor = connect.cursor()
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
    except:
        print("Error: unable to fetch data")
    connect.close()

def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)



def send_text(webhook, content, mentioned_list=None, mentioned_mobile_list=None):
    header = {
                "Content-Type": "application/json",
                "Charset": "UTF-8"
                }
    data ={

        "msgtype": "text",
        "text": {
            "content": content
            ,"mentioned_list":mentioned_list
            ,"mentioned_mobile_list":mentioned_mobile_list
        }
    }
    data = json.dumps(data)
    info = requests.post(url=webhook, data=data, headers=header)


#def get_cont(state_type, workflow_name, user_name):
  #  cont = "- [数据仓库项目调度工作流运行状态监控]\n"
  #  cont += "- 运行状态: " + state_type + "\n"
   # cont += "- 工作流名称: " + workflow_name + "\n"
   # cont += "- 执行人: " + user_name + "\n"
   # return cont


def get_cont(state_type,workflow_name,user_name):
    cont = '- ' + "**<font color=\"#858585\"  > [数据仓库项目调度工作流运行状态监控]</font>** " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 运行状态：</font>** <font color=\"#858585\"  > " + state_type + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 工作流名称：</font>** <font color=\"#858585\"  > " + workflow_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 执行人：</font>** <font color=\"#858585\"  > " + user_name + "</font> " + '\n'
    return cont

def get_cont_res(cont1):
    cont = cont1 + '- ' + "**<font color=\"#858585\"  > 工作流运行状态：</font><font color=\"#FF0000\" > 存在非成功状态工作流</font>** \n"
    return cont


def get_additional_content(webhook_url,phone):
    # 这里是您想要获取的额外内容的逻辑
    content = "小企提醒"

    send_text(webhook_url, content,mentioned_mobile_list=phone)  # 调用企业机器人的send_text函数

    return content
# 调用示例

def analysis_processing(env,min):
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=min)).strftime("%Y-%m-%d %H:%M:%S")
    # process_definition = "select case when state=0  then '提交成功' when  state=1  then '正在运行'  when  state=2  then '准备暂停' when  state=3  then '暂停' when  state=4  then '准备停止' " \
    #                      "when state=5  then '停止' when state=6  then '失败'  when state=7  then '成功'  when state=8  then '需要容错'  when state=9  then 'Kill'  when state=10  then '等待线程' " \
    #                      "when state=11  then '等待依赖完成'  when state=12  then '延时执行' else '其他状态' end  state,count(*) unnormal_cnt " \
    #                      "from  dolphinscheduler.t_ds_process_instance " \
    #                      "where  process_definition_code in ( " \
    #                      "select  code " \
    #                      "from  dolphinscheduler.t_ds_process_definition " \
    #                      "where  project_code=1 and  start_time>= curdate() and state!=7 ) " \
    #                      "group  by  state"

    process_definition = "select t2.name workflow_name,t1.state,t3.user_name,t3.phone " \
                         "from (select process_definition_code,case when state=0  then '提交成功' when  state=1  then '正在运行'  when  state=2  then '准备暂停' when  state=3  then '暂停' when  state=4  then '准备停止'  " \
                         "when state=5  then '停止' when state=6  then '失败'  when state=7  then '成功'  when state=8  then '需要容错'  when state=9  then 'Kill'  when state=10  then '等待线程'  " \
                         "when state=11  then '等待依赖完成'  when state=12  then '延时执行' else '其他状态' end  state,executor_id " \
                         "from  dolphinscheduler.t_ds_process_instance " \
                         "where   start_time>= curdate() ) t1 " \
                         "left join (  " \
                         "select  code,name  from  dolphinscheduler.t_ds_process_definition     where  project_code=1 ) t2 " \
                         "on  t1.process_definition_code=t2.code " \
                         "left join dolphinscheduler.t_ds_user t3 " \
                         "on t1.executor_id=t3.id " \
                         "where t2.code is not null  and t1.state!='成功' " \
                         "order by t1.state"

    print(process_definition)

    result_process_definition = get_data_from_mysql(process_definition)

    if len(result_process_definition) > 0:  ##如果要整体输出则在下一行加  cont1=''
        for result in result_process_definition:
            workflow_name = str(result[0])
            state_type = str(result[1])
            user_name = str(result[2])
            phone = result[3]
            cont = get_cont(state_type,workflow_name,user_name)
            cont1 = cont ## cont1 = cont1 +cont
        #print(cont1)
            cont1 = get_cont_res(cont1)
            print(cont1)
            content = cont1+'<@'+phone+'>'
            rs = send_md(webhook, content)


def main():
    try:
        # 每10分钟，执行一次
        # 执行数据获取多冗余1分钟 保证不漏发
        analysis_processing("生产环境",11)
    except (KeyboardInterrupt, SystemExit):
        sys.exit("程序退出~")


if __name__ == '__main__':
    main()