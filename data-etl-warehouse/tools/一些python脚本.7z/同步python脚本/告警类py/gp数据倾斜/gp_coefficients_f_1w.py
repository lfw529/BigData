import requests
import json
import psycopg2
import datetime

# 远程Greenplum数据库连接参数
def query_from_gp(sql):
    # 建立数据库连接
    conn = psycopg2.connect(
        host='10.30.250.135',
        port= 5432,
        database='ads',
        user='dev_user',
        password='DevUser@#20211111'
    )

    # 在此处添加需要执行的SQL查询或操作
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        return rows
    except psycopg2.Error as e:
        print('连接到远程Greenplum数据库时发生错误:')
        print(e)
# 关闭连接
        cursor.close()
        conn.close()

def get_cont(rtable_name,table_name,r_rate,pt_day,sup_update_time):
    cont = '- ' + "**<font color=\"#858585\"  > 任务执行状态：</font><font color=\"#FF0000\" > GP表数据倾斜告警</font>** \n" + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 倾斜表id：</font>** <font color=\"#858585\"  > " + rtable_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 倾斜库名：</font>** <font color=\"#858585\"  > " + table_name + "</font> " + '\n'
    #cont = cont + '- ' + "**<font color=\"#858585\"  > 任务执行状态：</font><font color=\"#FF0000\" > 任务执行告警</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 倾斜表名：</font>** <font color=\"#858585\"  > " + r_rate + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 倾斜系数：</font>** <font color=\"#858585\"  > " + pt_day + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警时间：</font>** <font color=\"#858585\"  > " + sup_update_time + "</font> " + '\n'
    return cont


# 发送文本消息
def send_text(webhook, content, mentioned_list=None, mentioned_mobile_list=None):
    header = {
                "Content-Type": "application/json",
                "Charset": "UTF-8"
                }
    data ={

        "msgtype": "text",
        "text": {
            "content": content
            ,"mentioned_list":mentioned_list
            ,"mentioned_mobile_list":mentioned_mobile_list
        }
    }
    data = json.dumps(data)
    info = requests.post(url=webhook, data=data, headers=header)


# 发送markdown消息
def send_md(webhook, content):
    header = {
                "Content-Type": "application/json",
                "Charset": "UTF-8"
                }
    data ={

        "msgtype": "markdown",
        "markdown": {
            "content": content
        }
    }
    data = json.dumps(data)
    info = requests.post(url=webhook, data=data, headers=header)
#webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723"

#send_text(webhook, content='ccc', mentioned_mobile_list=[18634767864])
#send_md(webhook, content='# ff \n 微信 ')

if __name__ == '__main__':
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=11)).strftime("%Y-%m-%d %H:%M:%S")
    #print(monitoring_time)
    sql = """select *  from dev.tpm_gp_coefficients_f_1w order by sup_update_time desc limit 10;"""
    #获取pg数据库连接
    rs = query_from_gp(sql)
    #print(rs)

    for i in rs:
        rtable_name = i[0]
        table_name = i[1]
        r_rate = i[2]
        pt_day = i[3]
        sup_update_time= i[4]
        msg = get_cont(str(rtable_name),str(table_name),str(r_rate),str(pt_day),str(sup_update_time))
        #print(msg)
        webhook = ""
        #webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723"
        content = msg
        #content='# GP数据异常监控 \n GP数据异常监控'''+msg''''''
        #rs = xiaoding.send_markdown(title='[实时表数据异常监控]',
                                   #text="## [""实时表数据异常监控]\n" + msg,
                                   #is_at_all=True)
        rs = send_md(webhook, content)
   # rs2 = send_text(webhook, content='小企提醒', mentioned_mobile_list=[18634767864])