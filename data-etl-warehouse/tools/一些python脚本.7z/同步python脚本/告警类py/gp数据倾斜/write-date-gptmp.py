import psycopg2
import datetime

conn = psycopg2.connect(
    host='10.30.250.135',
    port=5432,
    database='ads',
    user='dev_user',
    password='DevUser@#20211111'
)
# 远程Greenplum数据库连接参数
def query_from_gp(sql):
    # 建立数据库连接
    # 在此处添加需要执行的SQL查询或操作
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        return rows
    except psycopg2.Error as e:
        print('连接到远程Greenplum数据库时发生错误:')
        print(e)
# 关闭连接
        cursor.close()
        conn.close()


if __name__ == '__main__':
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=11)).strftime("%Y-%m-%d %H:%M:%S")
    #print(monitoring_time)
    sql="""SELECT cast(a.skcoid as text) as skcoid, cast(a.skcnamespace as text) as skcnamespace, cast(a.skcrelname as text) as skcrelname, cast(a.skccoeff as text) as skccoeff, TO_CHAR(current_timestamp, 'YYYY-MM-DD') as sup_update_time FROM gp_toolkit.gp_skew_coefficients a INNER JOIN pg_stat_user_tables b ON     a.skcrelname = b.relname     AND a.skcnamespace = b.schemaname WHERE     b.n_live_tup > 10000 ORDER BY     a.skccoeff DESC LIMIT 3;"""
    #sql = """SELECT id,cust_code,cust_name,cust_id,TO_CHAR(current_timestamp, 'YYYY-MM-DD') FROM ads.inf_cust_indust_responsible_f limit 3;"""
    #获取pg数据库连接
    rs = query_from_gp(sql)
    # 遍历查询结果并插入到另一张表
    insert_sql = "INSERT INTO dev.tpm_gp_coefficients_f_1w (skcoid, skcnamespace, skcrelname, skccoeff, sup_update_time) VALUES (%s, %s, %s, %s, %s)"
    cursor = conn.cursor()
    for row in rs:
        cursor.execute(insert_sql, row)
    conn.commit()

    # 关闭数据库连接
    cursor.close()
    conn.close()
