import paramiko
import re
import time
import traceback
import requests

### 钉钉监控 ###
#webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式
mastername = 'bdgpmaster-p-01'

def get_gp_state(hostname):
    # 实例化ssh客户端
    ssh = paramiko.SSHClient()
    # 创建默认的白名单
    policy = paramiko.AutoAddPolicy()
    # 设置白名单
    ssh.set_missing_host_key_policy(policy)
    # 获取免密登录key
    # pkey = '/root/.ssh/id_rsa'
    # key = paramiko.RSAKey.from_private_key_file(pkey)
    # ssh.load_system_host_keys()
    # 链接服务器
    ssh.connect(
        hostname=hostname  # 服务器的ip
        ,port=22  # 服务器的端口
        ,username = "gpadmin" #服务器的用户名
        # ,pkey=key
        ,password = "Gp@$202110" #用户名对应的密码
    )
    # 远程执行命令
    # stdin, stdout, stderr = ssh.exec_command("su - gpadmin  -c 'gpstate -b'")
    stdin, stdout, stderr = ssh.exec_command("gpstate -b")
    # exec_command 返回的对象都是类文件对象
    # stdin 标准输入 用于向远程服务器提交参数，通常用write方法提交
    # stdout 标准输出 服务器执行命令成功，返回的结果  通常用read方法查看
    # stderr 标准错误 服务器执行命令错误返回的错误值  通常也用read方法
    result = stdout.readlines()
    return result

def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)

def get_msg_cont(state_key, info, moni_time):
    cont = '- ' + "**<font color=\"#858585\"  > [greenplum监控]</font><font color=\"#FF0000\"  > " + state_key + "</font>** " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > GP异常级别：</font><font color=\"#FF0000\"  > " + state_key + "</font>** " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 监控时间：</font>** <font color=\"#858585\"  > " + moni_time + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > GP异常说明：</font>** <font color=\"#858585\"  > " + info + "</font> " + '\n'
    return cont

def get_exc_msg_cont(msg, msg_detail, moni_time):
    cont = '- ' + "**<font color=\"#858585\"  > 监控执行异常：</font><font color=\"#FF0000\"  > " + msg + "</font>** " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 监控时间：</font>** <font color=\"#858585\"  > " + moni_time + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 异常说明：</font>** <font color=\"#858585\"  > " + msg_detail + "</font> " + '\n'
    return cont

def greenplum_moni(mastername,env):
    try:
        state_detial = get_gp_state(mastername)
        moni_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        print (moni_time)
        res_tr = r'\[(.*?)\]'
        for state_str in state_detial:
            state = re.findall(res_tr, state_str, re.S | re.M)
            for state_key in state:
                print(state_key)
                if state_key != 'INFO':
                    info = state_str.split(':-')[1]
                    cont1 = get_msg_cont(state_key, info, moni_time)
                    content = cont1
                    rs = send_md(webhook, content)
                    #xiaoding.send_markdown(title='[greenplum监控]',text="## [" + env + "greenplum监控]\n" + cont1,is_at_all=True)
    except Exception:
        msg_detail = traceback.format_exc()
        msg = "greenplum状态获取异常"
        moni_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        print("Error: " + msg + ":" + msg_detail)
        cont1 = get_exc_msg_cont(msg, msg_detail, moni_time)
        content = cont1
        rs = send_md(webhook, content)
        #xiaoding.send_markdown(title='[greenplum监控]',text="## [" + env + "greenplum监控]\n" + cont1,is_at_all=True)

def main():
    greenplum_moni(mastername, "生产环境")

if __name__ == '__main__':
    main()



