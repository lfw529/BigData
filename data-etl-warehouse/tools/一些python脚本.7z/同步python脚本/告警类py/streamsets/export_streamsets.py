import json

import requests

### streamsets 服务器 ###
#url = "http://10.30.250.25"
url = '${streamsets_url}'
datafile ="/tmp/tmp_file/"


headers = {
    'Authorization': 'Basic YWRtaW46YWRtaW4='
}


def ExportJson(url):
    try:
        GetPipelineIDUrl = url + ":18630/rest/v1/pipelines/status"
        #print(url2)
        response2 = requests.get(GetPipelineIDUrl, headers=headers)
        if response2.status_code == 200:
            jsondata  = json.loads(response2.text)
            listdata = list (jsondata.keys())
            #print(listdata)
            for i in listdata:
                ExportUrl = url + ":18630/rest/v1/pipeline/"+ i +"/export?rev=0&includePlainTextCredentials=true"
                exportResponse=requests.get(ExportUrl,headers = headers)
                print(datafile+i+".json")
                with open(datafile+i+".json", "w+", encoding="UTF-8") as f:
                    f.write(exportResponse.text)
        else:
            print("获取ID请求发送失败")
    except Exception as e:
        print(e)
        exit(1)

if __name__ == '__main__':
        ExportJson(url)

