import requests
import json


### 监控 ###
#webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式

def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)


### streamsets 服务器 ###
url_list1 = ["http://10.30.250.24","http://10.30.250.25"]
#url_list2 = ["http://bdtool-t-01","http://bdtool-t-02"]
user = "admin"
passwd = "admin"


def get_cont(title,pip_id,status,msg,ser_url):
    msg='null'
    url_link = ser_url+":18630/collector/pipeline/"+pip_id
    cont = '- ' + "**<font color=\"#858585\"  > [streamset监控]</font> " + '\n'
    cont = cont +'- ' + "**<font color=\"#858585\"  > title：</font>** <font color=\"#858585\"  > " + title + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > pipelineid：</font>** <font color=\"#858585\"  > " + pip_id + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > status：</font><font color=\"#FF0000\" > " + status + "</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > msg：" + msg + "</font>** \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > url: [streamsets地址](" + url_link + ")</font>** \n"
    return cont

def get_pipeline_status(url,user,passwd):
    url2 = url + ':18630/rest/v1/pipelines?includeStatus=true'
    response2 = requests.get(url2, auth=(user, passwd))
    response2.raise_for_status()
    data = response2.text
    json_val = json.loads(data)
    return  json_val

def moni_status(url_list,env):
    for url in url_list:
        host_ip = url.split('.')[3]
        key_list = []
        val_list = []
        val = get_pipeline_status(url, user, passwd)
        for title in val[0]:
            key_list.append(title['pipelineId'])
            val_list.append(title['title'])
        json_str = dict(zip(key_list, val_list))
        title_json = json.loads(json.dumps(json_str))
        for str in val[1]:
            pip_id = str['pipelineId']
            print(title_json[pip_id], pip_id, str['status'],str['message'])
            if str['status'] not in ['EDITED','FINISHED','RUNNING','STOPPED']:
                cont1 = get_cont(title_json[pip_id], pip_id, str['status'],str['message'],url)
                content = cont1
                rs = send_md(webhook, content)
                #xiaoding.send_markdown(title='[streamsets监控]', text="## [" + env + "streamsets工作流监控(" + host_ip + ")] \n" + cont1,
                                    #   is_at_all=True)

if __name__ == "__main__":
    moni_status(url_list1,"生产")
    #moni_status(url_list2,"测试")

