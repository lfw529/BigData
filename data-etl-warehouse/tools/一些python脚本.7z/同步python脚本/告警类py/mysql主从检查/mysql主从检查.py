# 检查mysql 从节点运行状态
import pymysql
import requests



#webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式


def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)


# 发信方的信息：发信邮箱，QQ 邮箱授权码
#from_addr = 'cuijunle@supcon.com'
#password = 'cjl134679852@'
# 收信方邮箱
#to_addr1 = 'cuijunle@supcon.com'
# 发信服务器
#smtp_server = 'mail.supcon.com'
msg=''

if __name__ == '__main__':
    sqllist = [
        ['10.30.250.28',3306,'root','supcon@2021']    #从库1
    ]
    for i in sqllist:
        try:
            sqlcon = pymysql.connect(host=i[0], port=i[1], user=i[2], passwd=i[3])
            sqlcur = sqlcon.cursor()
            sqlcur.execute("show slave status")
            sqlcon.commit()
            data = sqlcur.fetchall()
            for idt in data :
                Master_Host=idt[1]
                Slave_IO_Running=idt[10]
                Slave_SQL_Running=idt[11]
                # log = str(i)
            if Slave_IO_Running =='Yes' and Slave_SQL_Running == 'Yes':
                 print('MasterSlave status is ok!')
            else:
                msg = 'Mysql从节点:'+i[0]+'异常,请检查\n'
                content = msg
                rs = send_md(webhook, content)
                #msg = MIMEText(msg, 'html', 'utf-8')
                # 邮件头信息
                #msg['From'] = Header('【大数据平台Mysql从节点异常告警】')  # 发送者
                #subject = '【大数据平台Mysql从节点异常告警】'
                #msg['Subject'] = Header(subject, 'utf-8')  # 邮件主题

                #smtpobj = smtplib.SMTP_SSL(smtp_server)
                # 建立连接--qq邮箱服务和端口号（可百度查询）
                #smtpobj.connect(smtp_server, 465)
                # 登录--发送者账号和口令
                #smtpobj.login(from_addr, password)
                # 发送邮件
                #smtpobj.sendmail(from_addr, to_addr1, msg.as_string())
                #print("邮件发送成功")
                #smtpobj.quit()
        except:
            print('Cannot get slave status,please check your mysqlconnect!')




