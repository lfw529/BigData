import sys
import requests
import pymysql
import json
import jsonpath
import datetime

### 钉钉监控 ###
#webhook = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=76924986-0c4b-40f7-8623-398d2342a723'   ##正式

webhook =
def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)

def get_data_from_mysql(sql):
    connect = pymysql.connect(
        host='bdmysql-p-01',
        port=3306,
        database='dolphinscheduler',
        user='cdh_user',
        passwd='Cdh#@20211014',
        charset='utf8',
        init_command="SET SESSION time_zone='+08:00'")
    cursor = connect.cursor()
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
    except:
        print("Error: unable to fetch data")
    connect.close()


def get_cont(project_name, workflow_name, work_name, user_name, fail_retry_times, fail_retry_interval):
    cont = '- ' + "**<font color=\"#858585\"  > [调度失败重试配置监控]</font>**" + '\n'
    cont = cont +'- ' + "**<font color=\"#858585\"  > 项目名称：</font>** <font color=\"#858585\"  > " + project_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 工作流名称：</font>** <font color=\"#858585\"  > " + workflow_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务名称：</font>** <font color=\"#858585\"  > " + work_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 执行人：</font>** <font color=\"#858585\"  > " + user_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 失败重试次数：</font>** <font color=\"#858585\" > " + fail_retry_times + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 失败重试间隔时间：</font>** <font color=\"#858585\" > " + fail_retry_interval + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务失败重试监测：</font><font color=\"#FF0000\" > 任务失败重试配置不规范</font>** \n"
    return cont

def get_fault_cont(title,hosts,start_time,typename,event,level,alert_log):
    cont = '- ' + "**<font color=\"#858585\"  > 告警类型：</font>** <font color=\"#858585\"  > " + title + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警服务器：</font>** <font color=\"#858585\"  > " + hosts + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 服务告警时间：</font>** <font color=\"#858585\"  > " + start_time + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 角色：</font>** <font color=\"#FF0000\"  > " + typename + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 事件：</font>** <font color=\"#858585\" > " + event + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 告警级别：</font><font color=\"#858585\" > " + level + "</font>**  \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > alert告警日志：</font>** <font color=\"#858585\"  > " + alert_log + "</font> " + '\n'
    return cont

def analysis_processing(env,min):
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=min)).strftime("%Y-%m-%d %H:%M:%S")
    process_definition = "select tp.name project_name,tf.workflow_name,tc.name work_name,td.user_name ,tc.fail_retry_times,tc.fail_retry_interval,td.phone " \
                         "from (  " \
                         "select code,name,project_code,user_id,fail_retry_times,fail_retry_interval " \
                         "from dolphinscheduler.t_ds_task_definition  " \
                         "where ( fail_retry_times<3 or fail_retry_interval<2 ) and project_code in (1,3,4) " \
                         ") tc  " \
                         "left join dolphinscheduler.t_ds_user td " \
                         "on tc.user_id=td.id  " \
                         "left join dolphinscheduler.t_ds_project tp " \
                         "on tc.project_code=tp.code " \
                         "left join( " \
                         "select distinct ta.task_code,tb.workflow_name " \
                         "from ( " \
                         "select task_code,process_instance_id,state,executor_id " \
                         "from dolphinscheduler.t_ds_task_instance  " \
                         "where start_time>= curdate() ) ta  " \
                         "left join ( " \
                         "select t1.id,t2.name workflow_name,t3.release_state  " \
                         "from dolphinscheduler.t_ds_process_instance t1 " \
                         "left join( select id,code,name from dolphinscheduler.t_ds_process_definition ) t2 " \
                         "on t1.process_definition_code = t2.code and t1.start_time >= curdate() " \
                         "left join dolphinscheduler.t_ds_schedules t3 " \
                         "on t2.code = t3.process_definition_code  " \
                         "where t1.start_time>=curdate() and t2.code is not null  " \
                         ") tb " \
                         "on ta.process_instance_id = tb.id " \
                         "where tb.workflow_name is not null and tb.release_state is not null " \
                         ") tf " \
                         "on tc.code = tf.task_code " \
                         "where tf.workflow_name is not null "

    print(process_definition)

    result_process_definition = get_data_from_mysql(process_definition)

    if len(result_process_definition) > 0:
        for result in result_process_definition:
            project_name = result[0]
            workflow_name = result[1]
            work_name = result[2]
            user_name = result[3]
            fail_retry_times = str(result[4])
            fail_retry_interval = str(result[5])
            phone = result[6]
            cont1 = get_cont(project_name, workflow_name, work_name, user_name, fail_retry_times, fail_retry_interval)
            print(cont1)
            content = cont1 + '<@' + phone + '>'
            rs = send_md(webhook, content)
            #xiaoding.send_markdown(title='[调度任务监控]',
                                  # text="## [" + env + "调度任务监控]\n" + cont1,
                                  # is_at_all=True)

            #xiaoding.send_markdown(title='[调度失败重试配置监控]',
                                   #text="## [" + env + "调度失败重试配置监控]\n" + cont1,
                                   #is_at_all=True)

def main():
    try:
        # 每10分钟，执行一次
        # 执行数据获取多冗余1分钟 保证不漏发
        analysis_processing("生产环境",11)
    except (KeyboardInterrupt, SystemExit):
        sys.exit("程序退出~")


if __name__ == '__main__':
    main()