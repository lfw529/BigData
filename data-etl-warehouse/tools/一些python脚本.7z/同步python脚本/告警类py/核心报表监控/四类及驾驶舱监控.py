import requests
import json
import psycopg2
import datetime

headers = {'Content-Type': 'application/json;charset=utf-8'}

### 钉钉监控 ###
#webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=97c882f6-3d79-483f-940c-57445e6f9bd2"   ##正式
# 远程Greenplum数据库连接参数
def query_from_gp(sql):
    # 建立数据库连接
    conn = psycopg2.connect(
        host='10.30.250.135',
        port= 5432,
        database='ads',
        user='dev_user',
        password='DevUser@#20211111'
    )

    # 在此处添加需要执行的SQL查询或操作
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        return rows
    except psycopg2.Error as e:
        print('连接到远程Greenplum数据库时发生错误:')
        print(e)
# 关闭连接
        cursor.close()
        conn.close()


def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)


def get_cont(report_name,task_name,task_type,process_name,start_time):
    cont = '- ' + "**<font color=\"#858585\"  > [" + report_name + "报表监控]</font>**" + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 监控指标：</font>** <font color=\"#858585\"  > " + task_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 监控状态：</font>** <font color=\"#FF0000\"  > " + process_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 具体内容：</font>** <font color=\"#858585\"  > " + task_type + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 监控时间：</font>** <font color=\"#858585\" > " + start_time + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 请及时处理</font>**" + '\n'
    return cont

if __name__ == '__main__':
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=11)).strftime("%Y-%m-%d %H:%M:%S")
    #print(monitoring_time)
    sql = """SELECT report_name,check_cont,check_status,check_data,check_time FROM dev.dev_report_monitor
 where substring(check_time,1,13)=to_char(current_timestamp,'yyyy-MM-dd HH24') and check_status !='正常';"""
    #获取pg数据库连接
    rs = query_from_gp(sql)
    print(rs)
    for result in rs:
            report_name=result[0]
            task_name = result[1]
            process_name = result[2]
            task_type = str(result[3])
            start_time = result[4]
            if report_name=='新四类':
                phone = '0120223920'
                phone2='0120230928'
            else:
                phone = '0120230643'
                phone2='0120230928'
            cont1 = get_cont(report_name,task_name,task_type,process_name,start_time)
            print(cont1)
            content = cont1 + '<@' + phone + '>'+'<@' + phone2 + '>'
            rs = send_md(webhook, content)