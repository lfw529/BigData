import requests
import pymysql
import json
import datetime
import cx_Oracle

headers = {'Content-Type': 'application/json;charset=utf-8'}

### 钉钉监控 ###
#webhook = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=97c882f6-3d79-483f-940c-57445e6f9bd2"   ##正式

def send_md(webhook, content):
    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content,
        }
    }

    response = requests.post(url=webhook, json=data, headers=header)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print("Failed to send message. Status code:", response.status_code)


def get_data_from_oracle(sql):
    try:
        # 设置Oracle数据库连接信息
        dsn = cx_Oracle.makedsn(host='10.30.3.13', port='1521', sid='bidata')
        # 连接到Oracle数据库
        connection = cx_Oracle.connect('bidb', '8QR4qXnntg', dsn)
        cursor = connection.cursor()
        # 执行SQL查询
        cursor.execute(sql)
        # 获取查询结果
        results = cursor.fetchall()

        # 关闭游标和数据库连接
        cursor.close()
        connection.close()

        return results

    except cx_Oracle.DatabaseError as e:
        error_message = "无法从Oracle数据库获取数据: {}".format(e)
        print(error_message)



def get_cont(task_name,task_type,process_name,start_time):
    cont = '- ' + "**<font color=\"#858585\"  > [BYD报表监控]</font>**" + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务表名：</font>** <font color=\"#858585\"  > " + task_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 任务状态：</font>** <font color=\"#FF0000\"  > " + process_name + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 数据量较昨日：</font>** <font color=\"#858585\"  > " + task_type + "</font> " + '\n'
    cont = cont + '- ' + "**<font color=\"#858585\"  > 异常时间：</font>** <font color=\"#858585\" > " + start_time + "</font> \n"
    cont = cont + '- ' + "**<font color=\"#858585\"  > 请及时处理</font>**" + '\n'
    return cont

if __name__ == '__main__':
    monitoring_time = (datetime.datetime.now() - datetime.timedelta(minutes=11)).strftime("%Y-%m-%d %H:%M:%S")
    #print(monitoring_time)
    sql = """SELECT check_cont,check_status,check_data,check_time,supcon_uptime FROM BIDB.RPD_BYD_REPORT_QUALITY_CHECK_F
WHERE CHECK_STATUS!='正常' AND  substr(to_char(supcon_uptime,'yyyy-MM-dd hh24'),1,13)=to_char((SYSDATE),'yyyy-MM-dd hh24')"""
    #获取pg数据库连接
    rs = get_data_from_oracle(sql)
    print(rs)
    for result in rs:
            task_name = result[0]
            process_name = result[1]
            task_type = str(result[2])
            start_time = result[3]
            phone = '0120212883'
            cont1 = get_cont(task_name,task_type,process_name,start_time)
            print(cont1)
            content = cont1 + '<@' + phone + '>'
            rs = send_md(webhook, content)
