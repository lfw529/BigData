# encoding: utf-8
#本脚本用于同步bpm  1.只修改 oracle_table =  oracle_table_comment =  2 注意一下"--num-mappers 4 \\\n" \"--split-by id \\\n" \
import re
import cx_Oracle as cx

# --------------------------------------
# 建立数据库连接（参数在这里改）
# --------------------------------------
ip = '10.33.32.21'
sid = 'bpmdata'
port = '1521'
db = 'grouphr'
user = 'kibug'
pwd = 'supcon1304'
oracle_system = 'bpm'
oracle_table = 'contract_gather_view'
oracle_table_comment = '销售合同一览表'
hive_databases = 'ods'

# ip = '10.40.0.22'
# sid = 'orcl'
# port = 10017
# db = 'bpmdev'
# user = 'bpmdev'
# pwd = 'sH20uc5t'
# oracle_system = 'bpm'
# oracle_table = 'sgs_forecasts'
# oracle_table_comment = ''
# hive_databases = 'ods'

dsn_tns = cx.makedsn(ip, port, sid)
#获取数据库连接
connection=cx.connect(user, pwd ,dsn_tns)
cursor = connection.cursor()

#获取表字段信息
res = cursor.execute("SELECT ut.COLUMN_NAME,ut.DATA_TYPE,ut.DATA_LENGTH,UT.DATA_SCALE,uc.comments from all_tab_columns ut inner JOIN all_col_comments uc on ut.TABLE_NAME = uc.table_name and ut.COLUMN_NAME = uc.column_name where uc.owner='GROUPHR' and ut.owner='GROUPHR' AND  ut.Table_Name='" + oracle_table.upper() + "'order by ut.column_id").fetchall()

cursor.close()
connection.close()

def sql():
    str_data = ''
    for i in res:
        result = re.sub('None','',str(i[0]) + " " + str(i[1]) + "(" + str(i[2]) + "," + str(i[3]) + ")" + " comment '" + str(i[4]) + "',")
        str_data = str_data + result
    return str_data

sql = ''.join(str(sql()))
sql = re.sub(",\)",")",re.sub("',","',\n",sql)).strip(',\n').lower()

# step1、替换sql建表语法
s0 = re.sub('( varchar.* comment| clob.* comment| char.* comment)',' string comment', sql) # 把varchar、clob等类似转换成string
s1 = re.sub(' timestamp.* comment| date.* comment',' string comment', s0) # 把timestamp类似转换成string
s2 = re.sub(' number\((\d|\d\d),0\) comment',' bigint comment', s1) # 把类似number(19,0)、number(1,0)类型的转换成bigint
s3 = re.sub(' number.* comment',' double comment', s2) #把类似浮点类型的转换成double

# step2、生成hive建表语句
hive_create = "select *  from ods." + hive_databases + "_" + oracle_system + "_" + db + "_" + oracle_table + "_f_1d;\n" \
"create table if not exists ods." + hive_databases + "_" + oracle_system + "_" + db + "_" + oracle_table + "_f_1d (\n" \
+ s3 + "\n"\
")\n" \
"COMMENT '" + oracle_table_comment + "'  ------表备注名\n" \
"partitioned by (pt_day string comment '分区日期,格式:yyyyMMdd') ------表分区\n" \
"ROW FORMAT DELIMITED ------表格式限制关键字\n" \
"FIELDS TERMINATED BY '\\t' ------字段分隔符\n" \
"LINES TERMINATED BY '\\n' ------行分隔符\n" \
"NULL DEFINED AS ''\n" \
"STORED AS textfile;"

print(hive_create)

# step3、生成sqoop语法
# 获取hive所有字段


string1 =re.findall(".* string.* comment .*", s0) # 获取hive中数据类型是string的列(时间、日期字段除外)
str_string1 = ''.join(string1)
string2 = re.sub(',','\n',str_string1) # 一行转多行
string_columns = re.sub(' string.* comment .*','',string2).split("\n") # 去掉数据类型、注释等后缀


data=[]
str_data=''
#定义一个方法，获取sqoop需要用到的字段
def sqoop_col():
    str_data=''
    for i in s3.split('\n'):
        all_columns = i.split(' ')[0] # 获取所有字段
        if all_columns in string_columns: # 判断：如果被文本可以匹配上，添加replace等语法，否则取原字段
            # print(r"trim(regexp_replace(replace(replace(replace(" + all_columns + ",chr(10),';'),chr(13),''),chr(9),' '),' {1,}',' ')) as " + all_columns + ",")
            str_data=str_data+"trim(regexp_replace(replace(replace(replace(" + all_columns + ",chr(10),';'),chr(13),''),chr(9),' '),' {1,}',' ')) as " + all_columns + ","
            data.append("trim(regexp_replace(replace(replace(replace(" + all_columns + ",chr(10),';'),chr(13),''),chr(9),' '),' {1,}',' ')) as " + all_columns + ",")
        else:
            # print(all_columns + ',')
            str_data=str_data+all_columns + ','
            data.append(all_columns + ',')
    return data,str_data
sqoop_sql = ''.join(str(sqoop_col()[1])).strip(',')
# print(sqoop_sql)

sqoop_shell = "sqoop import \\\n" \
"-Dmapreduce.job.queuename=root.offline \\\n" \
"--connect jdbc:oracle:thin:${bpm_ip_port_db}" + " \\\n" \
"--username " + "${username}" + " \\\n" \
"--password " + "${password}" + " \\\n" \
"--delete-target-dir \\\n" \
"--target-dir /tmp/" + hive_databases + "_" + oracle_system + "_" + db + "_" + oracle_table + "_f_1d`date +%s` \\\n" \
"--query \"select " + sqoop_sql + " from " + db.upper() + "." + oracle_table.upper() + " where \$CONDITIONS\" \\\n" \
"--mapreduce-job-name sqoop_" + hive_databases + "_" + oracle_system + "_" + db + "_" + oracle_table + "_f_1d_${bizdate} \\\n" \
"--fields-terminated-by '\\t' \\\n" \
"--lines-terminated-by '\\n' \\\n" \
"--num-mappers 4 \\\n" \
"--split-by id \\\n" \
"--hive-import \\\n" \
"--hive-drop-import-delims \\\n" \
"--hive-overwrite \\\n" \
"--hive-table " + hive_databases + "." + hive_databases + "_" + oracle_system + "_" + db + "_" + oracle_table + "_f_1d \\\n" \
"--hive-partition-key pt_day \\\n" \
"--hive-partition-value ${bizdate} \\\n" \
"--null-string '' \\\n" \
"--null-non-string ''"

print(sqoop_shell)