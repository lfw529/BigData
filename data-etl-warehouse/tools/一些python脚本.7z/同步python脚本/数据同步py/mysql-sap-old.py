import re

oracle_system = 'dmp'
oracle_database = 'db_cdh6_hive'  ##mysql库
oracle_table = 'dbs'
oracle_table_comment = '数据库信息'
hive_databases = 'ods'
sql = """db_id bigint comment '数据库id',
desc varchar(255) comment '',
db_location_uri varchar(255) comment '数据库地址',
name varchar(255) comment '用户',
owner_name varchar(255) comment 'owner',
owner_type varchar(255) comment 'owner类型',
create_time bigint comment '创建时间'""".lower()



# step1、替换sql建表语法
s0 = re.sub('( varchar.* comment| clob.* comment)',' string comment', sql) # 把varchar、clob等类似转换成string
s1 = re.sub(' timestamp.* comment',' string comment', s0) # 把timestamp类似转换成string
s2 = re.sub(' number\((\d|\d\d),0\) comment',' bigint comment', s1) # 把类似number(19,0)、number(1,0)类型的转换成bigint
s3 = re.sub('( number.* comment| decimal.* comment)',' double comment', s2) #把类似浮点类型的转换成double

# step2、生成hive建表语句
hive_create = "drop table if exists ods." + hive_databases + "_" + oracle_system + "_" + oracle_database + "_" + oracle_table + "_f_1d;\n" \
"create table if not exists ods." + hive_databases + "_" + oracle_system + "_" + oracle_database + "_" + oracle_table + "_f_1d (\n" \
+ s3 + "\n"\
")\n" \
"COMMENT '" + oracle_table_comment + "'  ------表备注名\n" \
"partitioned by (pt_day string comment '分区日期,格式:yyyyMMdd') ------表分区\n" \
"ROW FORMAT DELIMITED ------表格式限制关键字\n" \
"FIELDS TERMINATED BY '\\t' ------字段分隔符\n" \
"LINES TERMINATED BY '\\n' ------行分隔符\n" \
"NULL DEFINED AS ''\n" \
"STORED AS textfile;"

print(hive_create)

# step3、生成sqoop语法
# 获取hive所有字段


string1 =re.findall(".* string.* comment .*", s0) # 获取hive中数据类型是string的列(时间、日期字段除外)
str_string1 = ''.join(string1)
string2 = re.sub(',','\n',str_string1) # 一行转多行
string_columns = re.sub(' string.* comment .*','',string2).split("\n") # 去掉数据类型、注释等后缀


data=[]
str_data=''
#定义一个方法，获取sqoop需要用到的字段
def sqoop_col():
    str_data=''
    for i in s3.split('\n'):
        all_columns = i.split(' ')[0] # 获取所有字段
        if all_columns in string_columns: # 判断：如果被文本可以匹配上，添加replace等语法，否则取原字段
            # print(r"trim(regexp_replace(replace(replace(replace(" + all_columns + ",chr(10),';'),chr(13),''),chr(9),' '),' {1,}',' ')) as " + all_columns + ",")
            str_data=str_data+"trim(replace(replace(replace(replace(" + all_columns + ",char(10),';'),char(13),''),char(9),' '),' {1,}',' ')) as " + all_columns + ","
            data.append("trim(replace(replace(replace(replace(" + all_columns + ",char(10),';'),char(13),''),char(9),' '),' {1,}',' ')) as " + all_columns + ",")
        else:
            # print(all_columns + ',')
            str_data=str_data+all_columns + ','
            data.append(all_columns + ',')
    return data,str_data
sqoop_sql = ''.join(str(sqoop_col()[1])).strip(',')
# print(sqoop_sql)

sqoop_shell = "sqoop import \\\n" \
"-Dmapreduce.job.queuename=root.offline \\\n" \
"--connect ${dmp_ip_port_db} \\\n" \
"--username ${username} \\\n" \
"--password ${password} \\\n" \
"--delete-target-dir \\\n" \
"--target-dir /tmp/" + hive_databases + "_" + oracle_system + "_" + oracle_database + "_" + oracle_table + "_f_1d`date +%s` \\\n" \
"--query \"select " + sqoop_sql + " from " + oracle_database.lower() + "." + oracle_table.lower() + " where \$CONDITIONS\" \\\n" \
"--mapreduce-job-name sqoop_" + hive_databases + "_" + oracle_system + "_" + oracle_database + "_" + oracle_table + "_f_1d_${bizdate} \\\n" \
"--fields-terminated-by '\\t' \\\n" \
"--lines-terminated-by '\\n' \\\n" \
"--num-mappers 4 \\\n" \
"--split-by id \\\n" \
"--hive-import \\\n" \
"--hive-drop-import-delims \\\n" \
"--hive-overwrite \\\n" \
"--hive-table " + hive_databases + "." + hive_databases + "_" + oracle_system + "_" + oracle_database + "_" + oracle_table + "_f_1d \\\n" \
"--hive-partition-key pt_day \\\n" \
"--hive-partition-value ${bizdate} \\\n" \
"--null-string '' \\\n" \
"--null-non-string ''"

print(sqoop_shell)



