#此脚本用作rods层DDL和DML语句生成，并上传至HDFS
# 导入MySQL驱动:
import pymysql
import re
#from hdfs import InsecureClient
#需要填入ods表名
ods_name='ods_ehr_vwork_pt_user_stru_cache_f_1d'

# 获取rods表名
rods = re.sub('ods_', 'rods_', ods_name)
rods_name = re.sub('_1d', '_kudu', rods)

#获取filename
filename = rods_name+'.impala.sql'

#hdfs 目录
#hdfs_path='/script/impala_sql/ods_to_rods'

def getddl(tname):
    conn=pymysql.connect(host = '10.30.250.27' # 连接名称，默认127.0.0.1
    ,user = 'root' # 用户名
    ,passwd='supcon@2021' # 密码
    ,port= 3306 # 端口，默认为3306
    ,db='db_cdh6_hive' # 数据库名称
    ,charset='utf8' # 字符编码
    )
    cursor = conn.cursor()
    sql1 = '''
    select concat('`',COLUMN_NAME,'`') COLUMN_NAME,
    (case when col.TYPE_NAME='date' then 'timestamp' 
    when col.TYPE_NAME='timestamp' then 'timestamp' 
    when col.TYPE_NAME='datetime' then 'timestamp' 
    when col.TYPE_NAME='string' then 'string' 
    else col.TYPE_NAME end)  TYPE_NAME ,
    ifnull(col.COMMENT,'') COMNMENT
    from ( select * from  tbls where TBL_NAME =\''''+ods_name+'''\' order by DB_ID  limit 1 ) tab 
    left join sds  on tab.SD_ID  = sds.SD_ID 
    left join columns_v2 col on sds.CD_ID  = col.CD_ID 
    where COLUMN_NAME not like '/%'
      order  by col.INTEGER_IDX;'''

    #order
   # by
    #sds.INTEGER_IDX

    fields = ''
    fields2 =''
    rs = ''
    cursor.execute(sql1)
    results = cursor.fetchall()
    for row in results:
        column_name = row[0]
        column_type = row[1]
        column_comment = row[2]
        #拼接字段和类型
        fields += str(column_name)+' '+str(column_type) + ' comment \''+column_comment+ '\', \n'
        fields2 += str(column_name)+' ,\n'
    fields = fields + ' PRIMARY KEY (`id`)'
    fields2 = fields2.rstrip(' ,\n')
    rs1 = '''-------------------------------------------------------------------
-- 开发者：穆丽茹
-- 上线时间：2023.9.12
-- 脚本名称：
-- 脚本说明：测试环境
-- 依赖表：'''+ods_name+'''
-- 修改日志：
--------------------------------------------------------------------
drop table if exists rods.'''+rods_name+''';
create table if not exists rods.'''+rods_name+'''(
'''+fields+'''
)
PARTITION BY HASH (id) PARTITIONS 8 STORED AS KUDU TBLPROPERTIES ('kudu.master_addresses' = 'bdmaster-t-01:7051,bdmaster-t-02:7051');'''
    rs2 = '''
upsert into table rods.'''+rods_name+'''
select 
'''+fields2+'''
from  
ods.'''+ods_name+'''
where pt_day='${var:bizdate}' ;'''
    cursor.close()
    conn.close()
    rs = rs1+rs2
    return  rs


def write_infile(filename,context):
    with open(filename,'w+',encoding="UTF-8") as file_obj:
        file_obj.write(context)
        file_obj.close()
        return file_obj


#获取HDFS连接
#def getHDFSConn():
 #   client = None
  #  try:
   #     client = InsecureClient("http://bdmaster-p-01:9870/", user="hdfs",root='/')
    #except Exception as e:
     #   print('获取hdfs连接失败')
    #return client
#文件上传至HDFS
#def putLocalFileToHDFS(client, hdfs_path, local_path):
  #  try:
   #     client.upload(hdfs_path, local_path, cleanup=True)
   #     print('文件已上传至HDFS')
    #except Exception as e:
    #    print('文件上传hdfs失败')

if __name__ == '__main__':
    #获取sql语句
    rs = getddl(ods_name)
    print(rs)
    #写入本地文件
    write_infile(filename,rs)
    #获取hdfs连接
    #client=getHDFSConn()
    #删除HDFS文件
    #client.delete(hdfs_path + '/' +filename)
    #上传HDFS文件
    #putLocalFileToHDFS(client,hdfs_path,filename)