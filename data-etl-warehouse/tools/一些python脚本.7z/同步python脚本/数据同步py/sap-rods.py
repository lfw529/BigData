import pyhdb
import re

db = 'saphanadb'
mysql_system = 'sap'
mysql_table = 'ztfi043'
mysql_table_comment = ''
hive_databases = 'rods'

def get_connection():
    conn_obj = pyhdb.connect(
        host = "10.30.2.97", #HANA地址
        port = 30015, #HANA端口号
        user = "ZKBIREAD", #用户号
        password = "sd3R#F4FD"
    )
    return conn_obj

def get_mat(conn,sql):
    cursor = conn.cursor()
    cursor.execute(sql)      #连接表和视图都可以
    mat = cursor.fetchall()
    return mat
    cursor.close()




#获取表字段信息
#sql1 ='''SELECT 	A.FIELDNAME, 	A.DATATYPE, 	A.LENG, 	A.DECIMALS, 	CASE 		WHEN A.ROLLNAME = 'SAPHANADB' THEN B.DDTEXT 		ELSE C.DDTEXT 	END AS DDTEXT FROM 	SAPHANADB.DD03L A LEFT JOIN SAPHANADB.DD03T B ON 	B.TABNAME = A.TABNAME 	AND B.FIELDNAME = A.FIELDNAME 	AND B.DDLANGUAGE = '1' 	AND B.AS4LOCAL = 'A' LEFT JOIN SAPHANADB.DD04T C ON 	C.ROLLNAME = A.ROLLNAME 	AND C.DDLANGUAGE = '1' 	AND C.AS4LOCAL = 'A' WHERE 	A.LENG <> 0 	AND A.TABNAME =\''''+ mysql_table.upper() +'''\''''
sql1 ='''SELECT 	A.FIELDNAME, 	ut.DATA_TYPE_NAME, 	A.LENG, 	A.DECIMALS, 	CASE 		WHEN A.ROLLNAME = 'SAPHANADB' THEN B.DDTEXT 		ELSE C.DDTEXT 	END AS DDTEXT FROM 	SAPHANADB.DD03L A LEFT JOIN SAPHANADB.DD03T B ON 	B.TABNAME = A.TABNAME 	AND B.FIELDNAME = A.FIELDNAME 	AND B.DDLANGUAGE = '1' 	AND B.AS4LOCAL = 'A' LEFT JOIN SAPHANADB.DD04T C ON 	C.ROLLNAME = A.ROLLNAME 	AND C.DDLANGUAGE = '1' 	AND C.AS4LOCAL = 'A' LEFT JOIN SYS.TABLE_COLUMNS ut ON A.FIELDNAME=ut.COLUMN_NAME 	AND ut.SCHEMA_NAME = 'SAPHANADB' AND ut.Table_Name =\''''+ mysql_table.upper() +'''\'    WHERE 	A.LENG <> 0 	AND A.TABNAME =\''''+ mysql_table.upper() +'''\''''
#sql1 ='''SELECT ut.COLUMN_NAME,  ut.DATA_TYPE_NAME,  ut.LENGTH,  ut.IS_NULLABLE, uc.comments FROM 	SYS.TABLE_COLUMNS ut INNER JOIN TABLES uc ON 	ut.TABLE_NAME = uc.table_name WHERE 	uc.SCHEMA_NAME = 'SAPHANADB' 	AND ut.SCHEMA_NAME = 'SAPHANADB' 	AND ut.Table_Name =\''''+ mysql_table.upper() +'''\''''
print(sql1)

conn = get_connection()
res = get_mat(conn,sql1)

print(res)


def sql():
    str_data = ''
    for i in res:
        result = re.sub('None','',str(i[0]) + " " + str(i[1]) + "(" + str(i[2]) + "," + str(i[3]) + ")" + " comment '" + str(i[4]) + "',")
        str_data = str_data + result
    return str_data

sql = ''.join(str(sql()))
sql = re.sub(",\)",")",re.sub("',","',\n",sql)).strip(',\n').lower()

# step1、替换sql建表语法
s0 = re.sub('( nvarchar.* comment|varchar.* comment)',' string comment', sql) # 把varchar、clob等类似转换成string
s1 = re.sub(' timestamp.* comment| date.* comment',' string comment', s0) # 把timestamp类似转换成string
s2 = re.sub(' number\((\d|\d\d),0\) comment| int.* comment',' bigint comment', s1) # 把类似number(19,0)、number(1,0)类型的转换成bigint
s3 = re.sub(' dec.* comment|number.* comment|decimal.* comment',' double comment', s2) #把类似浮点类型的转换成double

# step2、生成hive建表语句
hive_create = "drop table if exists rods." + hive_databases + "_" + mysql_system + "_" + db + "_" + mysql_table + "_f_1h;\n" \
"create table if not exists rods." + hive_databases + "_" + mysql_system + "_" + db + "_" + mysql_table + "_f_1h (\n" \
+ s3 + "\n"\
")\n" \
"COMMENT '" + mysql_table_comment + "'  ------表备注名\n" \
"ROW FORMAT DELIMITED ------表格式限制关键字\n" \
"FIELDS TERMINATED BY '\\t' ------字段分隔符\n" \
"LINES TERMINATED BY '\\n' ------行分隔符\n" \
"NULL DEFINED AS ''\n" \
"STORED AS textfile;"

print(hive_create)

# step3、生成sqoop语法
# 获取hive所有字段


string1 =re.findall(".* string.* comment .*", s0) # 获取hive中数据类型是string的列(时间、日期字段除外)
str_string1 = ''.join(string1)
string2 = re.sub(',','\n',str_string1) # 一行转多行
string_columns = re.sub(' string.* comment .*','',string2).split("\n") # 去掉数据类型、注释等后缀


data=[]
str_data=''
#定义一个方法，获取sqoop需要用到的字段
def sqoop_col():
    str_data=''
    for i in s3.split('\n'):
        all_columns = i.split(' ')[0] # 获取所有字段
        if all_columns in string_columns: # 判断：如果被文本可以匹配上，添加replace等语法，否则取原字段
            # print(r"trim(regexp_replace(replace(replace(replace(" + all_columns + ",chr(10),';'),chr(13),''),chr(9),' '),' {1,}',' ')) as " + all_columns + ",")
            str_data=str_data+"trim(replace(replace(replace(replace(" + all_columns + ",char(10),';'),char(13),''),char(9),' '),' {1,}',' ')) as " + all_columns + ","
            data.append("trim(replace(replace(replace(replace(" + all_columns + ",char(10),';'),char(13),''),char(9),' '),' {1,}',' ')) as " + all_columns + ",")
        else:
            # print(all_columns + ',')
            str_data=str_data+all_columns + ','
            data.append(all_columns + ',')
    return data,str_data
sqoop_sql = ''.join(str(sqoop_col()[1])).strip(',')
# print(sqoop_sql)

sqoop_shell = "sqoop import \\\n" \
"-Dmapreduce.job.queuename=root.offline \\\n" \
"--connect jdbc:sap://10.30.2.97:30015/EHD?zerodatetimebehavior=converttonull" + " \\\n" \
"--driver com.sap.db.jdbc.Driver" + " \\\n" \
"--username " + "ZKBIREAD" + " \\\n" \
"--password " + "sd3R#F4FD" + " \\\n" \
"--delete-target-dir \\\n" \
"--target-dir /tmp/" + hive_databases + "_" + mysql_system + "_" + db + "_" + mysql_table + "_f_1h`date +%s` \\\n" \
"--query \"select " + sqoop_sql + " from " + db.upper() + "." + mysql_table.upper() + " where \$CONDITIONS\" \\\n" \
"--mapreduce-job-name sqoop_" + hive_databases + "_" + mysql_system + "_" + db + "_" + mysql_table + "_f_1h \\\n" \
"--fields-terminated-by '\\t' \\\n" \
"--lines-terminated-by '\\n' \\\n" \
"--num-mappers 4 \\\n" \
"--split-by id \\\n" \
"--hive-import \\\n" \
"--hive-drop-import-delims \\\n" \
"--hive-overwrite \\\n" \
"--hive-table " + hive_databases + "." + hive_databases + "_" + mysql_system + "_" + db + "_" + mysql_table + "_f_1h \\\n" \
"--null-string '' \\\n" \
"--null-non-string ''"

print(sqoop_shell)
