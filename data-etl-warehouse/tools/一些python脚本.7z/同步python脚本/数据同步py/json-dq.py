#-*- coding:utf-8 -*-

import json
import pandas as pd
data = open("C:/Users/muliru/Desktop/dataDict (1).json",encoding="utf-8").read()
data_list = json.loads(data)

df_result,index = pd.DataFrame(),0
for i in range(len(data_list[0]['models'])):
    df = {}
    for j in range(len(data_list[0]['models'][i]['attrs'])):
        df['index'] = index
        try:
            df['column'] = data_list[0]['models'][i]['attrs'][j]['column']
        except Exception as e:
            df['column'] = " "

        try:
            df['label'] = data_list[0]['models'][i]['attrs'][j]['label']
        except Exception as e:
            df['label'] = " "

        try:
            df['type'] = data_list[0]['models'][i]['attrs'][j]['type']
        except Exception as e:
            df['type'] = " "
        print(df)
        df_temp = pd.DataFrame(df, index=['index'])
        print(df_temp)
        df_result = pd.concat([df_temp, df_result], ignore_index=True)
        index = index + 1
print(df_result)
df_result.to_excel("C:/Users/muliru/Desktop/dataDict (1)结果表.xlsx", sheet_name="汇总", index=False)