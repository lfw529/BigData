from pyhive import hive
from datetime import datetime, timedelta
###清理hive--ods的历史分区
conn = hive.Connection(host='10.30.250.12', port=10000, username='hdfs')

cursor = conn.cursor()
cursor.execute("select  tbl_name from   ods.ods_dmp_db_cdh6_hive_tbls_f_1d where  pt_day = DATE_FORMAT(date_sub(current_date, 1), 'yyyyMMdd')  and tbl_name like '%_f_1d' and tbl_name like 'ods_%'")
results = [res[0] for res in cursor.fetchall()]
print(results)

# 获取当前日期并减去1天
current_date = datetime.now() - timedelta(days=3)
formatted_date = current_date.strftime("%Y%m%d")
print(formatted_date)

for table_name in results:
    try:
        sql1 = '''ALTER TABLE ods.{0} DROP PARTITION (pt_day < {1})'''.format(table_name, formatted_date)
        cursor.execute(sql1)
        print(f"Partition dropped for {table_name}")

    except Exception as e:
        print("An error occurred:", str(e))

# 关闭连接
cursor.close()
conn.close()