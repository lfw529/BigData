from pyhive import hive
import pymysql
import re
#import pandas as pd

###爬取hive中的表生成建表语句 pt_day 需要修改 ods_dmp_db_cdh6_hive_tbls_f_1d是元数据表
conn = hive.Connection(host='10.30.250.22', port=10000, username='hdfs')
# host主机ip,port：端口号，username:用户名，database:使用的数据库名称
cursor = conn.cursor()
cursor.execute("select  tbl_name from   ods.ods_dmp_db_cdh6_hive_tbls_f_1d where pt_day ='20231102' and tbl_name like 'ods_ehr%' and tbl_name like '%_1d' ")
results = [res[0] for res in cursor.fetchall()]
print(results)

#for i in range(0, len(results)):
       # if i <= len(results):
#table_name = results[1]
#print(table_name)
#conn = hive.Connection(host='10.30.250.22', port=10000, username='hdfs')
# host主机ip,port：端口号，username:用户名，database:使用的数据库名称
#cursor = conn.cursor()
#sql1 = '''show create table ods.'''+table_name+''''''
#cursor.execute(sql1)
#ddlresults = cursor.fetchall()
#print(ddlresults)
for i in range(0, len(results)):
        if i <= len(results):
            table_name = results[i]
            #print(table_name)

            conn = hive.Connection(host='10.30.250.22', port=10000, username='hdfs')
            cursor = conn.cursor()

            sql1 = '''SHOW CREATE TABLE ods.{}'''.format(table_name)
            cursor.execute(sql1)
            ddlresults = cursor.fetchall()
            #print(ddlresults)

            text_list = [item[0] for item in ddlresults]
            text = '\n'.join(text_list).strip()

            # step2、生成hive建表语句
            hive_create = "drop table if exists ods." + table_name + ";\n" \
                          + text + ";\n"
            #hive_create =  text + ";\n"

            print(hive_create)
            #print(text)
            print()

