#hdfs 下载文件
from hdfs import InsecureClient


directory = ['/script/impala_sql/ods_to_rods']  # 设置目录路径

#获取正式HDFS连接
def getPROHDFSConn():
    client = None
    try:
        client = InsecureClient("http://bdmaster-p-01:9870/", user="hdfs",root='/')
    except Exception as e:
        print('获取hdfs连接失败')
    return client


def get_profiles_in_directory(directory):
    file_list = []
    client = getPROHDFSConn()
    contents = client.list(directory, status=True)
    for file in contents:
        full_file_path = directory+'/'+file[0]
        if  not file[1]['type'] == 'DIRECTORY':
            file_list.append(full_file_path)

    client._session.close()
    return file_list

if __name__ == '__main__':
    proclient = getPROHDFSConn()
    for i  in directory:
        file_list = get_profiles_in_directory(i)
        for file in file_list:
            proclient.download(file,"C:/Users/cuijunle/PycharmProjects/DDL/linshi/")
