#脚本迁移，HDFS正式环境脚本迁移到测试环境
from hdfs import InsecureClient

# 递归获取目录下的所有文件
directory = ['/script/hive_sql',
             '/script/impala_sql',
             '/user/chenlinjia',
             '/user/heanni',
             '/user/huangxinyi',
             '/user/liucencen',
             '/user/liuyuhang',
             '/user/liyanghong',
             '/user/qinshunda',
             '/user/wangwei21',
             '/user/wangzhenglong',
             '/user/xugaojie',
             '/user/zhuxinlu'
             ]  # 设置目录路径

#获取正式HDFS连接
def getPROHDFSConn():
    client = None
    try:
        client = InsecureClient("", user="", root='/')
        #client = InsecureClient("http://bdmaster-p-01:9870/", user="hdfs",root='/')
    except Exception as e:
        print('获取hdfs连接失败')
    return client

#获取测试HDFS连接
def getTestHDFSConn():
    client = None
    try:
        client = InsecureClient("http://bdmaster-t-01:9870/", user="hdfs",root='/')
    except Exception as e:
        print('获取hdfs连接失败')
    return client


# 获取目录下的所有文件
def get_files_in_directory(directory):
    file_list = []
    client = getTestHDFSConn()
    contents = client.list(directory, status=True)
    for file in contents:
        full_file_path = directory+'/'+file[0]
        file_list.append(full_file_path)

    client._session.close()
    return file_list

def get_profiles_in_directory(directory):
    file_list = []
    client = getPROHDFSConn()
    contents = client.list(directory, status=True)
    for file in contents:
        full_file_path = directory+'/'+file[0]
        if  not file[1]['type'] == 'DIRECTORY' and  'sql' in full_file_path:
            file_list.append(full_file_path)

    client._session.close()
    return file_list

if __name__ == '__main__':
    #获取连接
    testclient = getTestHDFSConn()
    proclient = getPROHDFSConn()

    #判断测试环境目录是否存在，如果不存在就创建
    # for i in directory:
    #     if not testclient.status(i,strict=False):
    #         testclient.makedirs(i)
    #         print(f"创建HDFS目录：{i}")
    #     else:
    #         print(f"HDFS目录已存在：{i}")

    #删除测试目录下的所有文件
    # for i in directory:
    #     filelist = get_files_in_directory(i)
    #     for filepath in filelist:
    #         testclient.delete(filepath,recursive=True)
    #         print("删除成功")

    #文件传输
    for i in directory:
        flist = get_profiles_in_directory(i)
        for file in flist:
            print(file)
            with proclient.read(file) as read_stream,testclient.write(file)  as write_stream:
                for chunk in read_stream:
                    write_stream.write(chunk)






