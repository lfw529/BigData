import requests
import json
import psycopg2
import datetime
##爬取gp中的表  生成gp建表语句 table_scheam需要更改
# 远程Greenplum数据库连接参数
def query_from_gp(sql):
    # 建立数据库连接
    conn = psycopg2.connect(
        host='10.30.250.135',
        port= 5432,
        database='ads',
        user='dev_user',
        password='DevUser@#20211111'
    )

    # 在此处添加需要执行的SQL查询或操作
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        return rows
    except psycopg2.Error as e:
        print('---连接到远程Greenplum数据库时发生错误:')
        #print(e)
# 关闭连接
        cursor.close()
        conn.close()

table_scheam='ads'

sql = """SELECT DISTINCT 	"table_name" FROM 	information_schema.tables t1, 	pg_class t2 WHERE 	table_schema = '{}' 	AND t1."table_name" = t2.relname;""".format(table_scheam)
rows = query_from_gp(sql)
results = [res[0] for res in rows]
print(results)
print(len(results))



for i in range(0,len(results)):
        if i <= len(results):
            table_name = results[i]
            sql2= '''select
array_to_string( array (
select ret from
(
select \'drop table if exists ads.{} ;\n' ||
\'CREATE TABLE ads.{} (\n' || array_to_string(array (
select sql 
from
(
(--字段信息
select array_to_string(array (
select A.attname || \' \' || concat_ws ( \'\', T.typname, SUBSTRING ( format_type ( A.atttypid, A.atttypmod ) from \'\(.*\)\' ) ) || \' \' ||
case A.attnotnull when \'t\' then \'NOT NULL\' else \'\' end || \' \' ||
case when D.adbin is not null then \' DEFAULT \' || pg_get_expr ( D.adbin, A.attrelid ) else \'\' end 
from
pg_attribute
A left join pg_description b on A.attrelid = b.objoid 
and A.attnum = b.objsubid
left join pg_attrdef D on A.attrelid = D.adrelid 
and A.attnum = D.adnum,
pg_type T 
where
A.attstattarget =- 1 
and A.attrelid = \'ads.{} \' :: REGCLASS :: OID 
and A.attnum > 0 
and not A.attisdropped 
and A.atttypid = T.OID 
order by A.attnum ), \',\' || CHR(10) ) sql, 1 seri 
) 
union
(--约束（含主外键）信息
select \'CONSTRAINT \' || conname || \' \' || pg_get_constraintdef (OID) sql, 2 seri 
from pg_constraint T 
where conrelid = \'ads.{}\' :: REGCLASS :: OID 
order by contype desc 
) 
order by seri  
) T 
), \',\' || CHR(10) ) || \')\' as ret, 1 as orderby 
union --索引信息
select array_to_string(array (SELECT \'distributed by (\'||string_agg (a.attname, \',\') attby 
FROM 
(
SELECT oid, nspname, relname,CASE WHEN trim(splitted_value) <> '' THEN splitted_value::int ELSE NULL END AS attnu
FROM (
SELECT c.oid,n.nspname,c.relname, regexp_split_to_table(array_to_string(distkey, ' '), ' ') AS splitted_value
FROM gp_distribution_policy d 
LEFT JOIN pg_class c ON c.oid = d.localoid 
LEFT JOIN pg_namespace n ON n.oid = c.relnamespace  
WHERE c.oid = \'ads.{}\'::regclass
) subquery
) as att
LEFT JOIN pg_attribute a ON a.attrelid = att.oid
WHERE att.attnu = a.attnum
),  CHR(10) )|| \');\' as ret, 2 as orderby 
union --注释信息
select array_to_string(array (
select
\'COMMENT ON COLUMN \' || \'ads.{}.\' || A.attname || \' IS \'\'\' || b.description || \'\'\'\' 
from pg_attribute A 
left join pg_description b on A.attrelid = b.objoid 
and A.attnum = b.objsubid 
where
A.attstattarget =- 1 
and A.attrelid = \'ads.{}\' :: REGCLASS :: OID 
and b.description is not null 
order by
A.attnum 
), \';\' || CHR(10) )||\';\' as ret, 3 as orderby 
order by orderby 
) results 
), CHR(10)|| CHR(13) 
);'''.format(table_name,table_name,table_name,table_name,table_name,table_name,table_name)
            text_list1 = query_from_gp(sql2)
            if text_list1 is not None:
                text_list = [item[0] for item in text_list1]
                print('''-------------------ddl----------------''')
                text = '\n'.join(text_list).strip()
                print(text)
            else: print(i)


