from impala.dbapi import connect

#连接impala测试环境清理tmp盘的表 保留近7天
# 创建连接
conn = connect(host='10.30.250.36',port=21050,user='hdfs')
cursor = conn.cursor()
cursor.execute("select  tbl_name from ods.ods_dmp_db_cdh6_hive_tbls_f_1d a where pt_day = substr (regexp_replace (cast (date_sub (now (),1) as string),'-',''),1,8) and db_id = 4484 and from_unixtime(create_time,'yyyyMMdd')<substr (regexp_replace (cast (date_sub (now (),6) as string),'-',''),1,8) order by from_unixtime(create_time,'yyyyMMdd') desc")
results = [res[0] for res in cursor.fetchall()]
print(results)

for table_name in results:
    try:
        sql1 = '''drop TABLE tmp.{};'''.format(table_name)
        cursor.execute(sql1)
        print(f"Dropped for {table_name}")

    except Exception as e:
        print("An error occurred:", str(e))

# 关闭连接
conn.close()


##hive
#select from_unixtime(create_time), a.* from ods.ods_dmp_db_cdh6_hive_tbls_f_1d a where pt_day = DATE_FORMAT(date_sub(current_date, 7), 'yyyyMMdd') and db_id = 4484 and tbl_name like 'tmp%' and from_unixtime(create_time,'yyyyMMdd')<DATE_FORMAT(date_sub(current_date, 7), 'yyyyMMdd') order by from_unixtime(create_time,'yyyyMMdd') desc;