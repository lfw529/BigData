#次脚本用作dev层 外部表建设

# 导入MySQL驱动:
import pymysql
import re
#填入table表名
table_list=['dev_rdwd_fin_contract_amount_f_1h']
 ##dev.dev_rdwd_sale_fee_detail_f_1h
##dev.dev_rdwd_fin_receive_fact_f_1mon
def getddl(tname):
    table_name = tname

    conn=pymysql.connect(host = '10.30.250.27' # 连接名称，默认127.0.0.1
    ,user = 'root' # 用户名
    ,passwd='supcon@2021' # 密码
    ,port= 3306 # 端口，默认为3306
    ,db='db_cdh6_hive' # 数据库名称
    ,charset='utf8' # 字符编码
    )
    cursor = conn.cursor()
    #sql1 建表ddl
    sql1 = '''
    select COLUMN_NAME,
    (case when col.TYPE_NAME='date' then 'text' 
    when col.TYPE_NAME='timestamp' then 'text' 
    when col.TYPE_NAME='datetime' then 'text' 
    when col.TYPE_NAME='string' then 'text' 
    when col.TYPE_NAME='double' then 'double precision' 
    else col.TYPE_NAME end)  TYPE_NAME 
    from ( select * from  tbls where TBL_NAME =\''''+table_name+'''\'  order by DB_ID  limit 1 ) tab 
    left join sds  on tab.SD_ID  = sds.SD_ID 
    left join columns_v2 col on sds.CD_ID  = col.CD_ID 
    where COLUMN_NAME not like '/%'
    order by col.INTEGER_IDX ;
        '''
    #print(sql1)
    fields = ''
    cursor.execute(sql1)
    results = cursor.fetchall()
    for row in results:
        column_name = row[0]
        column_type = row[1]
        #拼接字段和类型
        fields += str(column_name)+' '+str(column_type)+', \n'
    #text 替换string
    fields=fields.rstrip(", \n")

    rs1='''drop external table if exists dev.'''+table_name+'''; '''+'''
    create external table  dev.'''+table_name+'''( \n'''+fields+''',
    pt_day text)
    LOCATION('pxf://dev.'''+table_name+'''?PROFILE=Hive&SERVER=cdh')
    FORMAT 'custom' (FORMATTER='pxfwritable_import');'''
    print('''-------------------ddl-------------------''')
    print(rs1)

    #sql2 注释ddl
    sql2 = '''
    select COLUMN_NAME,ifnull(col.COMMENT,'')
    from ( select * from  tbls where TBL_NAME =\''''+table_name+'''\'  order by DB_ID  limit 1 ) tab 
    left join sds  on tab.SD_ID  = sds.SD_ID 
    left join columns_v2 col on sds.CD_ID  = col.CD_ID 
    where COLUMN_NAME not like '/%'
    order by col.INTEGER_IDX ;
        '''
    cursor.execute(sql2)
    results = cursor.fetchall()
    rs2 =''
    for row in results:
        column_name = row[0]
        column_comment = row[1]
        rs2+='''COMMENT ON COLUMN dev.'''+table_name+'''.'''+column_name+''' is \''''+column_comment+'''\'; \n'''
    print('''-------------------comment---------------------''')
    print(rs2)

    rs3='''grant select on dev.'''+table_name +''' to dm_rpt_user;'''
    print('''-------------------grant---------------------''')
    print(rs3)

    cursor.close()
    conn.close()


if __name__ == '__main__':
    for i in table_list:
        getddl(i)