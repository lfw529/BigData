#次脚本用dev内部表创建
#新增功能：20230727 建表必须指定分布键
#新增功能：20230727 获取GP的表备注
#优化：20230727  返回float4 和 int4 减少存储和计算的资源
#优化：20230821  返回sqoop任务代码和copy表建表语句
# 导入MySQL驱动:
import pymysql

#填入table表名
table_list=['dmn_dept']
#填入分布键
pk = 'dept_id'


def getddl(tname):
    table_name = tname

    conn=pymysql.connect(host = '10.30.250.27' # 连接名称，默认127.0.0.1
    ,user = 'dev_user' # 用户名
    ,passwd='DevUser@#20211111' # 密码
    ,port= 3306 # 端口，默认为3306
    ,db='db_cdh6_hive' # 数据库名称
    ,charset='utf8' # 字符编码
    )
    cursor = conn.cursor()
    #sql1 获取字段类型
    sql1 = '''
    select COLUMN_NAME,
    (case when col.TYPE_NAME='date' then 'text' 
    when col.TYPE_NAME='timestamp' then 'text' 
    when col.TYPE_NAME='datetime' then 'text' 
    when col.TYPE_NAME='string' then 'text' 
    when col.TYPE_NAME='double' then 'float8' 
    when col.TYPE_NAME='bigint' then 'text'
    else col.TYPE_NAME end)  TYPE_NAME 
    from ( select * from  tbls where TBL_NAME =\''''+table_name+'''\'  order by DB_ID  desc limit 1 ) tab 
    left join sds  on tab.SD_ID  = sds.SD_ID 
    left join columns_v2 col on sds.CD_ID  = col.CD_ID 
    where COLUMN_NAME not like '/%'
    order by col.INTEGER_IDX ;
        '''
    #print(sql1)
    fields = ''
    cursor.execute(sql1)
    results = cursor.fetchall()
    for row in results:
        column_name = row[0]
        column_type = row[1]
        #拼接字段和类型
        fields += str(column_name)+' '+str(column_type)+', \n'
    fields=fields.rstrip(", \n")


    #正式表建表语句
    rs1='''drop  table if exists dmn.'''+table_name+'''; '''+'''
create  table  dmn.'''+table_name+'''( \n'''+fields+''')
distributed by ('''+pk+''');'''
    print('''-------------------ddl-------------------''')
    print(rs1)

    #获取hive表的备注信息
    sql3 = '''
       select 
       b.PARAM_VALUE hivetablename
       from 
       (select TBL_ID from  tbls where TBL_NAME =\'''' + table_name + '''\'  order by DB_ID  desc limit 1 ) a 
       inner join 
       (select * 
       from table_params where 
       PARAM_KEY='comment') b on a.TBL_ID = b.TBL_ID;
       '''
    cursor.execute(sql3)
    name = cursor.fetchone()
    for i in name:
        tablename = i


    #获取字段注释
    sql2 = '''
    select COLUMN_NAME,ifnull(col.COMMENT,'')
    from ( select * from  tbls where TBL_NAME =\''''+table_name+'''\'  order by DB_ID desc  limit 1 ) tab 
    left join sds  on tab.SD_ID  = sds.SD_ID 
    left join columns_v2 col on sds.CD_ID  = col.CD_ID 
    where COLUMN_NAME not like '/%'
    order by col.INTEGER_IDX ;'''
    cursor.execute(sql2)
    results = cursor.fetchall()
    rs2 =''
    for row in results:
        column_name = row[0]
        column_comment = row[1]
        rs2+='''COMMENT ON COLUMN dmn.'''+table_name+'''.'''+column_name+''' is \''''+column_comment+'''\'; \n'''
    rs3 = '''COMMENT ON TABLE dmn.'''+table_name+''' is \''''+tablename+'''\';\n'''+rs2
    print('''-------------------comment---------------------''')
    print(rs3)



    #copy表建表语句
    rs4 = '''drop  table if exists dmn.copy_''' + table_name + '''; ''' + '''
create  table  dmn.copy_''' + table_name + '''( \n''' + fields + ''')
distributed by (''' + pk + ''');'''
    print('''-------------------copy_ddl-------------------''')
    print(rs4)
    #copy表注释语句
    rs5 = ''
    for row in results:
        column_name = row[0]
        column_comment = row[1]
        rs5 += '''COMMENT ON COLUMN dmn.copy_''' + table_name + '''.''' + column_name + ''' is \'''' + column_comment + '''\'; \n'''
    rs6 = '''COMMENT ON TABLE dmn.copy_''' + table_name + ''' is \'''' + tablename + '''\';\n''' + rs5
    print('''-------------------copy_comment---------------------''')
    print(rs6)

    cursor.close()
    conn.close()


if __name__ == '__main__':
    for i in table_list:
        getddl(i)